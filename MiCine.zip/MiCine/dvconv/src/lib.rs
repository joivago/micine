//! Conversión al vuelo de Dolby Vision perfil 7 (doble capa, como en los remux de UHD Blu-ray)
//! a perfil 8.1, que la NVIDIA SHIELD sí reproduce.
//!
//! Cada fotograma de vídeo HEVC llega como una serie de unidades NAL precedidas de su longitud
//! (formato de Matroska/MP4). Para cada fotograma:
//!   - se eliminan las NAL de tipo 63 (UNSPEC63), que llevan la capa de mejora (FEL/MEL);
//!   - se convierten las NAL de tipo 62 (UNSPEC62), que llevan los metadatos RPU de Dolby Vision,
//!     del perfil 7 al 8.1 con el modo 2 de dovi_tool (el mismo que usa su orden `convert`).
//! La capa base (la imagen HDR10) no se toca: no hay recompresión ni pérdida en ella.

use dolby_vision::rpu::dovi_rpu::DoviRpu;
use dolby_vision::rpu::ConversionMode;

const NAL_UNSPEC62: u8 = 62; // RPU de Dolby Vision
const NAL_UNSPEC63: u8 = 63; // capa de mejora de Dolby Vision

fn nal_type(nal: &[u8]) -> u8 {
    if nal.is_empty() { 0 } else { (nal[0] >> 1) & 0x3F }
}

/// Recorre las NAL de un fotograma separadas por códigos de inicio (00 00 01 / 00 00 00 01),
/// que es como las entrega el lector de MKV de Media3 al reproductor.
fn split_annexb(sample: &[u8]) -> Option<Vec<&[u8]>> {
    let mut starts = Vec::new(); // posición donde empieza cada NAL (tras el código de inicio)
    let mut i = 0usize;
    while i + 3 <= sample.len() {
        if sample[i] == 0 && sample[i + 1] == 0 && sample[i + 2] == 1 {
            starts.push(i + 3);
            i += 3;
        } else {
            i += 1;
        }
    }
    if starts.is_empty() { return None; }
    // Antes del primer código de inicio solo puede haber ceros.
    if sample[..starts[0] - 3].iter().any(|&b| b != 0) { return None; }
    let mut out = Vec::with_capacity(starts.len());
    for (k, &st) in starts.iter().enumerate() {
        let mut end = if k + 1 < starts.len() { starts[k + 1] - 3 } else { sample.len() };
        while end > st && sample[end - 1] == 0 { end -= 1; } // ceros que pertenecen al siguiente código
        if end > st { out.push(&sample[st..end]); }
    }
    Some(out)
}

/// Recorre las NAL de un fotograma con prefijo de longitud de `len_size` bytes (1 a 4),
/// o separadas por códigos de inicio si `len_size` es 0.
fn split_nals(sample: &[u8], len_size: usize) -> Option<Vec<&[u8]>> {
    if len_size == 0 { return split_annexb(sample); }
    if !(1..=4).contains(&len_size) { return None; }
    let mut out = Vec::new();
    let mut pos = 0usize;
    while pos + len_size <= sample.len() {
        let mut n = 0usize;
        for i in 0..len_size { n = (n << 8) | sample[pos + i] as usize; }
        pos += len_size;
        if n == 0 { continue; }
        if pos + n > sample.len() { return None; } // fotograma mal formado: no se toca
        out.push(&sample[pos..pos + n]);
        pos += n;
    }
    if pos != sample.len() { return None; }
    Some(out)
}

fn push_nal(out: &mut Vec<u8>, nal: &[u8], len_size: usize) {
    if len_size == 0 { out.extend_from_slice(&[0, 0, 0, 1]); out.extend_from_slice(nal); return; }
    let n = nal.len();
    for i in (0..len_size).rev() { out.push(((n >> (8 * i)) & 0xFF) as u8); }
    out.extend_from_slice(nal);
}

/// Convierte la RPU de una NAL UNSPEC62 (con su cabecera 0x7C01) a perfil 8.1.
/// Devuelve la NAL nueva, o `None` si no es perfil 7 o no se puede leer.
pub fn convert_rpu_nal(nal: &[u8]) -> Option<Vec<u8>> {
    let mut rpu = DoviRpu::parse_unspec62_nalu(nal).ok()?;
    if rpu.dovi_profile != 7 { return None; }
    rpu.convert_with_mode(ConversionMode::To81).ok()?;
    rpu.write_hevc_unspec62_nalu().ok()
}

/// Perfil de Dolby Vision de la primera RPU del fotograma (0 si no hay RPU legible).
pub fn sample_profile(sample: &[u8], len_size: usize) -> u8 {
    if let Some(nals) = split_nals(sample, len_size) {
        for nal in nals {
            if nal_type(nal) == NAL_UNSPEC62 {
                if let Ok(rpu) = DoviRpu::parse_unspec62_nalu(nal) { return rpu.dovi_profile; }
            }
        }
    }
    0
}

/// Convierte un fotograma completo. Devuelve `None` si no había nada que cambiar
/// (así se reutiliza el original sin copiarlo).
pub fn convert_sample(sample: &[u8], len_size: usize) -> Option<Vec<u8>> {
    let nals = split_nals(sample, len_size)?;
    if !nals.iter().any(|n| matches!(nal_type(n), NAL_UNSPEC62 | NAL_UNSPEC63)) { return None; }
    let mut out = Vec::with_capacity(sample.len());
    let mut changed = false;
    for nal in nals {
        match nal_type(nal) {
            NAL_UNSPEC63 => { changed = true; } // fuera la capa de mejora
            NAL_UNSPEC62 => match convert_rpu_nal(nal) {
                Some(new_nal) => { push_nal(&mut out, &new_nal, len_size); changed = true; }
                None => push_nal(&mut out, nal, len_size), // si no se puede convertir, se deja como estaba
            },
            _ => push_nal(&mut out, nal, len_size),
        }
    }
    if changed { Some(out) } else { None }
}

// ---------------------------------------------------------------------------
// Puente JNI para Android: com.jivan.micine.DvConverter
// ---------------------------------------------------------------------------
#[cfg(not(test))]
mod android {
    use jni::objects::{JByteArray, JClass};
    use jni::sys::{jbyteArray, jint};
    use jni::JNIEnv;

    /// Devuelve el fotograma convertido, o null si no hay que cambiar nada.
    #[no_mangle]
    pub extern "system" fn Java_com_jivan_micine_DvConverter_nativeConvert<'local>(
        env: JNIEnv<'local>,
        _class: JClass<'local>,
        input: JByteArray<'local>,
        length: jint,
        nal_length_size: jint,
    ) -> jbyteArray {
        let data = match env.convert_byte_array(&input) { Ok(d) => d, Err(_) => return std::ptr::null_mut() };
        let len = (length.max(0) as usize).min(data.len());
        match super::convert_sample(&data[..len], nal_length_size as usize) {
            Some(out) => match env.byte_array_from_slice(&out) {
                Ok(arr) => arr.into_raw(),
                Err(_) => std::ptr::null_mut(),
            },
            None => std::ptr::null_mut(),
        }
    }

    /// Perfil de Dolby Vision del fotograma (0 si no se reconoce).
    #[no_mangle]
    pub extern "system" fn Java_com_jivan_micine_DvConverter_nativeProfile<'local>(
        env: JNIEnv<'local>,
        _class: JClass<'local>,
        input: JByteArray<'local>,
        length: jint,
        nal_length_size: jint,
    ) -> jint {
        let data = match env.convert_byte_array(&input) { Ok(d) => d, Err(_) => return 0 };
        let len = (length.max(0) as usize).min(data.len());
        super::sample_profile(&data[..len], nal_length_size as usize) as jint
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn asset(name: &str) -> Vec<u8> {
        let dir = std::env::var("DOVI_ASSETS").expect("DOVI_ASSETS");
        std::fs::read(format!("{}/{}", dir, name)).unwrap()
    }
    // Las muestras de dovi_tool son la NAL UNSPEC62 tal como va en el vídeo, con prefijo 00 00 00 01
    // en lugar de la cabecera 0x7C01. Se reconstruye la NAL completa.
    fn rpu_nal_from_bin(bin: &[u8]) -> Vec<u8> {
        assert_eq!(&bin[..4], &[0, 0, 0, 1]);
        let mut nal = vec![0x7C, 0x01];
        nal.extend_from_slice(&bin[4..]);
        nal
    }
    fn fake_sample(rpu_nal: &[u8]) -> Vec<u8> {
        let slice = vec![0x02, 0x01, 0xD0, 0x11, 0x22, 0x33, 0x44]; // NAL tipo 1 (imagen)
        let el = vec![0x7E, 0x01, 0x40, 0x01, 0x0C, 0x01, 0xAA, 0xBB]; // NAL tipo 63 (capa de mejora)
        let mut s = Vec::new();
        push_nal(&mut s, &slice, 4);
        push_nal(&mut s, &el, 4);
        push_nal(&mut s, rpu_nal, 4);
        s
    }

    fn check(orig: &str, expected: &str) {
        let sample = fake_sample(&rpu_nal_from_bin(&asset(orig)));
        assert_eq!(sample_profile(&sample, 4), 7);
        let out = convert_sample(&sample, 4).expect("debe cambiar");
        let nals = split_nals(&out, 4).unwrap();
        assert_eq!(nals.len(), 2, "queda la imagen y la RPU; la capa de mejora se elimina");
        assert_eq!(nal_type(nals[0]), 1);
        assert_eq!(nal_type(nals[1]), 62);
        let got = DoviRpu::parse_unspec62_nalu(nals[1]).unwrap();
        assert_eq!(got.dovi_profile, 8);
        // La referencia de dovi_tool se generó con el modo 2 antiguo, que conservaba las curvas de
        // la capa de mejora. El modo 2 actual las deja neutras (una recta), porque al quitar esa capa
        // ya no corresponden a la imagen. Se comprueba:
        let reference = DoviRpu::parse_unspec62_nalu(&asset(expected)).unwrap();
        //  1) los metadatos de imagen (brillo, niveles, recortes...) son idénticos a la referencia;
        assert_eq!(format!("{:?}", got.vdr_dm_data), format!("{:?}", reference.vdr_dm_data));
        //  2) las curvas quedan neutras: un solo tramo de 0 a 1023 por componente;
        let m = format!("{:?}", got.rpu_data_mapping);
        assert!(m.contains("num_pivots_minus2: [0, 0, 0]") || m.contains("num_pivots_minus2: 0"), "{m}");
        //  3) el modo antiguo reproduce la referencia byte a byte (lectura y escritura correctas).
        let mut old = DoviRpu::parse_unspec62_nalu(&rpu_nal_from_bin(&asset(orig))).unwrap();
        old.convert_with_mode(ConversionMode::To81MappingPreserved).unwrap();
        assert_eq!(old.write_hevc_unspec62_nalu().unwrap(), rpu_nal_from_bin(&asset(expected)));
        assert_eq!(sample_profile(&out, 4), 8);
    }

    #[test] fn fel_a_81() { check("fel_orig.bin", "fel_to_81.bin"); }

    #[test]
    fn con_codigos_de_inicio() {
        // Mismo fotograma, pero como lo entrega Media3: 00 00 00 01 + NAL.
        let rpu = rpu_nal_from_bin(&asset("fel_orig.bin"));
        let mut s = Vec::new();
        push_nal(&mut s, &[0x02, 0x01, 0xD0, 0x11, 0x22], 0);
        push_nal(&mut s, &[0x7E, 0x01, 0x40, 0x01], 0);
        push_nal(&mut s, &rpu, 0);
        assert_eq!(sample_profile(&s, 0), 7);
        let out = convert_sample(&s, 0).unwrap();
        assert_eq!(&out[..4], &[0, 0, 0, 1]);
        let nals = split_nals(&out, 0).unwrap();
        assert_eq!(nals.len(), 2);
        assert_eq!(nals[0], &[0x02, 0x01, 0xD0, 0x11, 0x22]);
        assert_eq!(nal_type(nals[1]), 62);
        assert_eq!(sample_profile(&out, 0), 8);
        // Códigos de 3 bytes también valen
        let mut s3 = vec![0, 0, 1, 0x02, 0x01, 0xAA];
        s3.extend_from_slice(&[0, 0, 1]); s3.extend_from_slice(&rpu);
        assert_eq!(sample_profile(&s3, 0), 7);
        assert!(convert_sample(&s3, 0).is_some());
        // Basura sin códigos de inicio: no se toca
        assert!(convert_sample(&[1, 2, 3, 4, 5], 0).is_none());
    }
    #[test] fn mel_a_81() { check("mel_orig.bin", "mel_to_81.bin"); }

    #[test]
    fn perfil8_no_se_toca() {
        let sample = {
            let mut s = Vec::new();
            push_nal(&mut s, &[0x02, 0x01, 0xD0, 0x11], 4);
            push_nal(&mut s, &rpu_nal_from_bin(&asset("profile8.bin")), 4);
            s
        };
        assert_eq!(sample_profile(&sample, 4), 8);
        assert!(convert_sample(&sample, 4).is_none());
    }

    #[test]
    fn sin_dolby_vision_no_se_toca() {
        let mut s = Vec::new();
        push_nal(&mut s, &[0x02, 0x01, 0xD0, 0x11], 4);
        assert!(convert_sample(&s, 4).is_none());
        assert!(convert_sample(&[0, 0, 0, 9, 1, 2], 4).is_none()); // longitud imposible
    }
}

#[cfg(test)]
mod speed {
    use super::*;
    #[test]
    fn velocidad() {
        let dir = std::env::var("DOVI_ASSETS").unwrap();
        let bin = std::fs::read(format!("{}/fel_orig.bin", dir)).unwrap();
        let mut rpu = vec![0x7C, 0x01]; rpu.extend_from_slice(&bin[4..]);
        let mut s = Vec::new();
        push_nal(&mut s, &vec![0x02u8; 400_000], 4);       // imagen de ~400 KB (4K remux)
        push_nal(&mut s, &vec![0x7Eu8, 0x01, 1, 2, 3], 4); // capa de mejora
        push_nal(&mut s, &rpu, 4);
        let t = std::time::Instant::now();
        for _ in 0..240 { assert!(convert_sample(&s, 4).is_some()); }
        let ms = t.elapsed().as_secs_f64() * 1000.0 / 240.0;
        println!("ms por fotograma: {ms:.3}");
        assert!(ms < 5.0);
    }
}

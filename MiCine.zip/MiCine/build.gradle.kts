plugins {
    // Las mismas versiones con las que se compila Media3 1.9.4
    id("com.android.application") version "8.12.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}

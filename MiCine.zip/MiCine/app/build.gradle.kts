plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jivan.micine"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jivan.micine"
        minSdk = 26
        targetSdk = 34
        versionCode = 8
        versionName = "1.7"
        ndk {
            // La SHIELD es ARM de 64 bits; se incluye también 32 bits por si acaso.
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    // Clave fija: cada versión nueva se instala encima de la anterior.
    signingConfigs {
        create("propia") {
            storeFile = file("micine.jks")
            storePassword = "micine"
            keyAlias = "micine"
            keyPassword = "micine"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("propia")
        }
        release {
            signingConfig = signingConfigs.getByName("propia")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }


    // La librería del conversor Dolby Vision (libdvconv.so) la compila el workflow de GitHub
    // con Rust y la deja en src/main/jniLibs antes de compilar la app.
}

val media3 = "1.9.4"

dependencies {
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-ui:$media3")
    implementation("androidx.media3:media3-common:$media3")
    implementation("androidx.media3:media3-extractor:$media3")
    // Decodificador FFmpeg: la LG C5 (2025) no admite DTS, así que la SHIELD lo descodifica
    // ella misma y lo manda como PCM multicanal, que sigue siendo sin pérdida.
    // Este decodificador solo existe para Media3 1.9; por eso no se sube de versión.
    implementation("org.jellyfin.media3:media3-ffmpeg-decoder:1.9.0+1")
    implementation("androidx.annotation:annotation:1.9.1")
}

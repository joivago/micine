// Reconoce título, año y datos técnicos a partir del nombre de un archivo de película.
// Ej.: «Jaws.1975.2160p.UHD.BluRay.REMUX.DV.HDR.HEVC.TrueHD.Atmos.7.1-FGT.mkv»
(function (root) {
  'use strict';

  var JUNK = /\b(2160p|1080p|720p|480p|4k|uhd|ultra ?hd|blu-?ray|bdrip|brrip|bdremux|remux|web-?dl|webrip|web|hdtv|dvdrip|hdr10\+?|hdr|dv|dovi|dolby ?vision|sdr|hevc|x265|h\.?265|x264|h\.?264|avc|10bit|8bit|truehd|atmos|dts(-?hd)?( ?ma)?|dts-?x|dd\+?|ddp|e-?ac-?3|ac-?3|aac|flac|lpcm|pcm|7\.1|5\.1|2\.0|multi|dual|castellano|espa(ñ|n)ol|spanish|latino|ingl(é|e)s|english|vose|vos|subs?|extended|director'?s ?cut|remastered|unrated|imax|criterion|repack|proper|hybrid|complete|bluray|disc ?\d)\b/i;

  function clean(s) { return String(s || '').replace(/\s+/g, ' ').trim(); }

  // Nombres que no dicen nada (y entonces se usa el de la carpeta).
  function isGeneric(name) {
    return /^(movie|pelicula|película|film|video|vídeo|main|feature|title_?t?\d+|t\d+|\d{3,5}|bdmv|stream)$/i.test(clean(name));
  }

  function parse(fileName, folderName) {
    var base = String(fileName || '').replace(/\.[a-z0-9]{2,4}$/i, '');
    if (isGeneric(base.replace(/[._]/g, ' ')) && folderName) base = folderName;

    var tech = techInfo(base + ' ' + (folderName || ''));
    var s = base.replace(/[._]+/g, ' ').replace(/\s*-\s*[A-Za-z0-9]+$/, function (m) {
      // «-FGT» al final es el grupo que lo publicó; «- La película» no.
      return /\s-\s/.test(m) ? m : '';
    });

    var year = null, title = s;
    // Candidatos a año: 19xx o 20xx sueltos o entre paréntesis/corchetes. El bueno es el último que
    // deja título delante (así «Blade Runner 2049 2017» → 2017 y «1917 (2019)» → 2019).
    var re = /(^|[\s(\[])((?:19|20)\d{2})(?=[)\]]?(?:[\s.\-\[(]|$))/g, mm, best = null;
    while ((mm = re.exec(s))) {
      var before = clean(s.slice(0, mm.index + mm[1].length).replace(/[\[(]+\s*$/, ''));
      if (before) best = { year: mm[2], title: before };
      re.lastIndex = mm.index + mm[0].length;
    }
    if (best) {
      title = best.title; year = best.year;
    } else {
      // Sin año: se corta en la primera etiqueta técnica.
      var j = s.search(JUNK);
      if (j > 0) title = s.slice(0, j);
    }
    title = clean(title.replace(/[\[(]+$/, '').replace(/\s-\s*$/, ''));
    if (!title) title = clean(s);
    return { title: title, year: year, tech: tech };
  }

  function techInfo(s) {
    var t = String(s).replace(/[._]/g, ' ');
    var has = function (re) { return re.test(t); };
    var video = [];
    if (has(/\b(2160p|4k|uhd)\b/i)) video.push('4K');
    else if (has(/\b1080p\b/i)) video.push('1080p');
    if (has(/\b(dv|dovi|dolby ?vision)\b/i)) video.push('Dolby Vision');
    if (has(/\bhdr10\+|hdr10plus\b/i)) video.push('HDR10+');
    else if (has(/\bhdr(10)?\b/i)) video.push('HDR10');
    var audio = '';
    if (has(/\btruehd\b/i)) audio = 'TrueHD';
    else if (has(/\bdts-?x\b/i)) audio = 'DTS:X';
    else if (has(/\bdts-?hd( ?ma)?\b/i)) audio = 'DTS-HD MA';
    else if (has(/\bdts\b/i)) audio = 'DTS';
    else if (has(/\b(ddp|dd\+|e-?ac-?3)\b/i)) audio = 'Dolby Digital Plus';
    else if (has(/\b(ac-?3|dd)\b/i)) audio = 'Dolby Digital';
    if (has(/\batmos\b/i)) audio = (audio ? audio + ' ' : '') + 'Atmos';
    var ch = (t.match(/\b([257])[ .]1\b/) || [])[0];
    if (ch) audio = clean(audio + ' ' + ch.replace(' ', '.'));
    return { remux: has(/\bremux\b/i), video: video, audio: audio };
  }

  var api = { parse: parse, techInfo: techInfo, isGeneric: isGeneric };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.FileName = api;
})(this);

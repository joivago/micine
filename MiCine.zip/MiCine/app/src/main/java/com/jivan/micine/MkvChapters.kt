package com.jivan.micine

import java.io.File
import java.io.RandomAccessFile
import java.util.Locale

/**
 * Lee los capítulos de un archivo MKV (elemento «Chapters» de Matroska).
 * Solo lee la cabecera del archivo: unos pocos kilobytes aunque la película ocupe 80 GB.
 */
object MkvChapters {

    data class Chapter(val startMs: Long, val title: String)

    private const val ID_EBML = 0x1A45DFA3L
    private const val ID_SEGMENT = 0x18538067L
    private const val ID_SEEKHEAD = 0x114D9B74L
    private const val ID_SEEK = 0x4DBBL
    private const val ID_SEEK_ID = 0x53ABL
    private const val ID_SEEK_POSITION = 0x53ACL
    private const val ID_CLUSTER = 0x1F43B675L
    private const val ID_CHAPTERS = 0x1043A770L
    private const val ID_EDITION = 0x45B9L
    private const val ID_EDITION_DEFAULT = 0x45DBL
    private const val ID_EDITION_HIDDEN = 0x45BDL
    private const val ID_ATOM = 0xB6L
    private const val ID_TIME_START = 0x91L
    private const val ID_FLAG_HIDDEN = 0x98L
    private const val ID_FLAG_ENABLED = 0x4598L
    private const val ID_DISPLAY = 0x80L
    private const val ID_STRING = 0x85L
    private const val ID_LANGUAGE = 0x437CL
    private const val ID_LANGUAGE_BCP47 = 0x437DL

    private const val UNKNOWN = -1L

    fun read(file: File): List<Chapter> {
        if (!file.name.lowercase(Locale.ROOT).let { it.endsWith(".mkv") || it.endsWith(".mk3d") || it.endsWith(".webm") }) return emptyList()
        return try {
            RandomAccessFile(file, "r").use { parse(Reader(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private class Reader(val f: RandomAccessFile) {
        val length = f.length()
        var pos: Long
            get() = f.filePointer
            set(v) = f.seek(v)

        fun byte(): Int { val b = f.read(); if (b < 0) throw java.io.EOFException(); return b }

        /** Identificador de elemento (se conserva el bit marcador). */
        fun id(): Long {
            val first = byte()
            var len = 1; var mask = 0x80
            while (len <= 4 && first and mask == 0) { len++; mask = mask shr 1 }
            if (len > 4) throw IllegalStateException("id")
            var v = first.toLong()
            repeat(len - 1) { v = (v shl 8) or byte().toLong() }
            return v
        }

        /** Tamaño de elemento (sin el bit marcador). UNKNOWN si es «tamaño desconocido». */
        fun size(): Long {
            val first = byte()
            var len = 1; var mask = 0x80
            while (len <= 8 && first and mask == 0) { len++; mask = mask shr 1 }
            if (len > 8) throw IllegalStateException("size")
            var v = (first and (mask - 1)).toLong()
            var allOnes = v == (mask - 1).toLong()
            repeat(len - 1) { val b = byte(); if (b != 0xFF) allOnes = false; v = (v shl 8) or b.toLong() }
            return if (allOnes) UNKNOWN else v
        }

        fun uint(n: Long): Long { var v = 0L; repeat(n.toInt().coerceAtMost(8)) { v = (v shl 8) or byte().toLong() }; if (n > 8) pos += n - 8; return v }
        fun bytes(n: Long): ByteArray { val b = ByteArray(n.toInt()); f.readFully(b); return b }
        fun string(n: Long): String = String(bytes(n), Charsets.UTF_8).trimEnd('\u0000').trim()
    }

    private fun parse(r: Reader): List<Chapter> {
        if (r.id() != ID_EBML) return emptyList()
        val headerSize = r.size()        // se lee antes de usar la posición
        r.pos = r.pos + headerSize
        if (r.id() != ID_SEGMENT) return emptyList()
        val segSize = r.size()
        val segStart = r.pos
        val segEnd = if (segSize == UNKNOWN) r.length else minOf(r.length, segStart + segSize)

        // Recorre los elementos de primer nivel hasta los clústeres de vídeo.
        var chaptersAt = -1L
        var p = segStart
        var guard = 0
        while (p < segEnd && guard++ < 64) {
            r.pos = p
            val id = r.id()
            val size = r.size()
            val dataStart = r.pos
            when (id) {
                ID_CHAPTERS -> return parseChapters(r, dataStart, size)
                ID_SEEKHEAD -> if (size != UNKNOWN) {
                    val found = seekTarget(r, dataStart, dataStart + size, ID_CHAPTERS)
                    if (found >= 0) chaptersAt = segStart + found
                }
                ID_CLUSTER -> break
            }
            if (size == UNKNOWN) break
            p = dataStart + size
        }
        // Los capítulos pueden estar al final del archivo: se va directo con el índice (SeekHead).
        if (chaptersAt in segStart until segEnd) {
            r.pos = chaptersAt
            if (r.id() == ID_CHAPTERS) {
                val size = r.size()
                return parseChapters(r, r.pos, size)
            }
        }
        return emptyList()
    }

    private fun seekTarget(r: Reader, start: Long, end: Long, wanted: Long): Long {
        var p = start
        while (p < end) {
            r.pos = p
            val id = r.id(); val size = r.size(); val ds = r.pos
            if (size == UNKNOWN) return -1
            if (id == ID_SEEK) {
                var q = ds; var sid = -1L; var spos = -1L
                while (q < ds + size) {
                    r.pos = q
                    val cid = r.id(); val cs = r.size(); val cds = r.pos
                    if (cid == ID_SEEK_ID) { val b = r.bytes(cs); sid = b.fold(0L) { a, x -> (a shl 8) or (x.toLong() and 0xFF) } }
                    else if (cid == ID_SEEK_POSITION) spos = r.uint(cs)
                    q = cds + cs
                }
                if (sid == wanted) return spos
            }
            p = ds + size
        }
        return -1
    }

    private fun parseChapters(r: Reader, start: Long, size: Long): List<Chapter> {
        if (size == UNKNOWN || size > 16L * 1024 * 1024) return emptyList()
        val end = start + size
        val editions = ArrayList<Pair<Boolean, List<Chapter>>>() // (por defecto, capítulos)
        var p = start
        while (p < end) {
            r.pos = p
            val id = r.id(); val s = r.size(); val ds = r.pos
            if (s == UNKNOWN) break
            if (id == ID_EDITION) {
                var isDefault = false; var hidden = false
                val atoms = ArrayList<Chapter>()
                var q = ds
                while (q < ds + s) {
                    r.pos = q
                    val cid = r.id(); val cs = r.size(); val cds = r.pos
                    when (cid) {
                        ID_EDITION_DEFAULT -> isDefault = r.uint(cs) == 1L
                        ID_EDITION_HIDDEN -> hidden = r.uint(cs) == 1L
                        ID_ATOM -> parseAtom(r, cds, cds + cs, atoms.size + 1)?.let { atoms.add(it) }
                    }
                    q = cds + cs
                }
                if (!hidden && atoms.isNotEmpty()) editions.add(isDefault to atoms)
            }
            p = ds + s
        }
        val chosen = (editions.firstOrNull { it.first } ?: editions.firstOrNull())?.second ?: return emptyList()
        return chosen.sortedBy { it.startMs }.distinctBy { it.startMs }
    }

    private fun parseAtom(r: Reader, start: Long, end: Long, number: Int): Chapter? {
        var startNs = -1L; var hidden = false; var enabled = true
        val names = ArrayList<Pair<String, String>>() // (idioma, texto)
        var p = start
        while (p < end) {
            r.pos = p
            val id = r.id(); val s = r.size(); val ds = r.pos
            if (s == UNKNOWN) break
            when (id) {
                ID_TIME_START -> startNs = r.uint(s)
                ID_FLAG_HIDDEN -> hidden = r.uint(s) == 1L
                ID_FLAG_ENABLED -> enabled = r.uint(s) != 0L
                ID_DISPLAY -> {
                    var text = ""; var lang = ""
                    var q = ds
                    while (q < ds + s) {
                        r.pos = q
                        val cid = r.id(); val cs = r.size(); val cds = r.pos
                        when (cid) {
                            ID_STRING -> text = r.string(cs)
                            ID_LANGUAGE -> if (lang.isEmpty()) lang = r.string(cs)
                            ID_LANGUAGE_BCP47 -> lang = r.string(cs)
                        }
                        q = cds + cs
                    }
                    if (text.isNotEmpty()) names.add(lang.lowercase(Locale.ROOT) to text)
                }
            }
            p = ds + s
        }
        if (startNs < 0 || hidden || !enabled) return null
        // Nombre en español si lo hay; si no, el primero.
        val name = names.firstOrNull { it.first == "spa" || it.first == "es" || it.first.startsWith("es-") }?.second
            ?: names.firstOrNull()?.second ?: ""
        return Chapter(startNs / 1_000_000, niceName(name, number))
    }

    /** «Chapter 05», «00:12:31.000» o vacío → «Capítulo 5». */
    private fun niceName(name: String, number: Int): String {
        val generic = Regex("""^(chapter|chapitre|kapitel|capitolo|cap[ií]tulo|cap\.?)\s*0*(\d+)$""", RegexOption.IGNORE_CASE)
        val m = generic.find(name.trim())
        return when {
            name.isBlank() -> "Capítulo $number"
            m != null -> "Capítulo ${m.groupValues[2]}"
            Regex("""^\d{1,2}:\d{2}(:\d{2})?([.,]\d+)?$""").matches(name.trim()) -> "Capítulo $number"
            else -> name
        }
    }
}

package com.jivan.micine

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Registro de lo que pasa al reproducir (formatos, cambios de pantalla, errores y cierres).
 * Se guarda en la propia app y se puede ver en Ajustes → «Ver registro de errores».
 */
object Registro {
    private const val FILE = "registro.txt"
    private const val CRASH_FLAG = "cierre_inesperado"
    private const val MAX = 120_000L
    private var installed = false
    private lateinit var dir: File

    /** Se llama al abrir cada pantalla. Instala el aviso de cierres inesperados una sola vez. */
    fun init(ctx: Context) {
        dir = ctx.applicationContext.filesDir
        if (installed) return
        installed = true
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, e ->
            try {
                add("CIERRE INESPERADO en «${thread.name}»:\n" + stack(e))
                File(dir, CRASH_FLAG).writeText("1")
            } catch (_: Throwable) {}
            previous?.uncaughtException(thread, e)
        }
    }

    @Synchronized
    fun add(text: String) {
        if (!this::dir.isInitialized) return
        try {
            val f = File(dir, FILE)
            if (f.length() > MAX) {
                // Se queda con la segunda mitad para no crecer sin límite.
                val keep = f.readText().takeLast((MAX / 2).toInt())
                f.writeText("…\n" + keep.substringAfter('\n'))
            }
            val time = SimpleDateFormat("dd/MM HH:mm:ss", Locale("es")).format(Date())
            f.appendText("$time  $text\n")
        } catch (_: Exception) {}
    }

    fun stack(e: Throwable): String {
        val w = StringWriter()
        e.printStackTrace(PrintWriter(w))
        // Lo importante: las primeras líneas y cada «Caused by» con sus 3 primeras.
        val lines = w.toString().lines().filter { it.isNotBlank() }
        val out = ArrayList<String>()
        var budget = 0
        for (l in lines) {
            if (l.startsWith("Caused by")) budget = 4
            if (out.size < 8 || budget > 0) { out += l; if (budget > 0) budget-- }
        }
        return out.joinToString("\n")
    }

    fun device(): String =
        "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"

    fun read(): String = try {
        File(dir, FILE).takeIf { it.exists() }?.readText() ?: ""
    } catch (e: Exception) { "" }

    fun clear() {
        try { File(dir, FILE).delete(); File(dir, CRASH_FLAG).delete() } catch (_: Exception) {}
    }

    /** true si la última vez la app se cerró por un error (y borra el aviso). */
    fun takeCrashFlag(): Boolean {
        val f = File(dir, CRASH_FLAG)
        return if (f.exists()) { f.delete(); true } else false
    }
}

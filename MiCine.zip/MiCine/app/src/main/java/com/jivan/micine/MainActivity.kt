package com.jivan.micine

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.storage.StorageManager
import android.os.storage.StorageVolume
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Pantalla principal: la interfaz (biblioteca, explorador, ajustes) está hecha en HTML
 * (carpeta assets/www) y se maneja con el mando. Esta clase le da acceso a los discos USB,
 * a los ajustes y abre el reproductor.
 */
class MainActivity : Activity() {

    companion object {
        private const val HOST = "appassets.androidplatform.net"
        private const val REQ_PERMISSION = 7
        private val VIDEO_EXT = setOf("mkv", "mp4", "m4v", "mov", "ts", "m2ts", "mts", "webm", "avi")
    }

    private lateinit var web: WebView
    private val settings by lazy { getSharedPreferences(Prefs.SETTINGS, Context.MODE_PRIVATE) }
    private val positions by lazy { getSharedPreferences(Prefs.POSITIONS, Context.MODE_PRIVATE) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(0xFF15110E.toInt())
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.isFocusable = true
        web.isFocusableInTouchMode = true
        web.addJavascriptInterface(Bridge(), "Native")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url
                if (url.host != HOST) return null
                val path = (url.path ?: "/").trimStart('/').ifEmpty { "index.html" }
                return try {
                    WebResourceResponse(mime(path), if (path.endsWith(".woff2")) null else "utf-8", assets.open("www/$path"))
                } catch (e: Exception) {
                    WebResourceResponse("text/plain", "utf-8", 404, "Not found", null, null)
                }
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.url.host != HOST
        }
        web.loadUrl("https://$HOST/index.html")
        web.requestFocus()
        listenForDrives()
    }

    override fun onResume() {
        super.onResume()
        // Al volver del reproductor: actualizar «seguir viendo».
        if (this::web.isInitialized) js("window.onAppResume && window.onAppResume()")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.appBack ? window.appBack() : false") { r -> if (r != "true") finish() }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(driveReceiver) } catch (e: Exception) {}
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    // ---------------- Discos USB ----------------

    private val driveReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            // Pequeña espera: el sistema tarda un instante en dejar el disco listo para leer.
            web.postDelayed({ js("window.onDrivesChanged && window.onDrivesChanged()") }, 1500)
        }
    }

    private fun listenForDrives() {
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_MEDIA_MOUNTED)
            addAction(Intent.ACTION_MEDIA_UNMOUNTED)
            addAction(Intent.ACTION_MEDIA_REMOVED)
            addAction(Intent.ACTION_MEDIA_EJECT)
            addDataScheme("file")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(driveReceiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(driveReceiver, f)
    }

    private fun volumeDir(v: StorageVolume): File? = try {
        if (Build.VERSION.SDK_INT >= 30) v.directory
        else (StorageVolume::class.java.getMethod("getPath").invoke(v) as? String)?.let { File(it) }
    } catch (e: Exception) { null }

    private fun volumes(): JSONArray {
        val sm = getSystemService(Context.STORAGE_SERVICE) as StorageManager
        val out = JSONArray()
        for (v in sm.storageVolumes) {
            if (v.state != Environment.MEDIA_MOUNTED && v.state != Environment.MEDIA_MOUNTED_READ_ONLY) continue
            val dir = volumeDir(v) ?: continue
            out.put(JSONObject().apply {
                put("name", if (v.isPrimary) "Almacenamiento interno" else (v.getDescription(this@MainActivity) ?: dir.name))
                put("path", dir.absolutePath)
                put("removable", v.isRemovable)
                put("free", dir.freeSpace)
                put("total", dir.totalSpace)
            })
        }
        return out
    }

    private fun isVideo(f: File) = f.extension.lowercase(Locale.ROOT) in VIDEO_EXT

    private fun listDir(path: String): JSONObject {
        val dir = File(path)
        val dirs = JSONArray()
        val files = JSONArray()
        val entries = dir.listFiles()?.filter { !it.name.startsWith(".") }?.sortedBy { it.name.lowercase(Locale.ROOT) } ?: emptyList()
        for (e in entries) {
            if (e.isDirectory) {
                if (e.name.equals("LOST.DIR", true) || e.name.equals("System Volume Information", true) || e.name.startsWith("\$")) continue
                dirs.put(JSONObject().put("name", e.name).put("path", e.absolutePath))
            } else if (isVideo(e)) {
                files.put(fileJson(e))
            }
        }
        return JSONObject().put("path", dir.absolutePath).put("parent", dir.parent ?: "")
            .put("dirs", dirs).put("files", files).put("readable", dir.canRead())
    }

    private fun fileJson(f: File) = JSONObject()
        .put("name", f.name).put("path", f.absolutePath).put("size", f.length())
        .put("mtime", f.lastModified()).put("folder", f.parentFile?.name ?: "")

    /** Busca películas por todo el disco (hasta 6 carpetas de profundidad). */
    private fun scanRoots(roots: List<String>): JSONArray {
        val out = JSONArray()
        fun walk(d: File, depth: Int) {
            if (depth > 6) return
            val list = d.listFiles() ?: return
            for (e in list) {
                if (e.name.startsWith(".")) continue
                if (e.isDirectory) {
                    val n = e.name.lowercase(Locale.ROOT)
                    if (n == "lost.dir" || n == "system volume information" || n.startsWith("\$") || n == "android") continue
                    walk(e, depth + 1)
                } else if (isVideo(e)) {
                    // Las muestras de prueba («sample») no son películas.
                    if (e.length() < 300L * 1024 * 1024 && e.name.lowercase(Locale.ROOT).contains("sample")) continue
                    out.put(fileJson(e))
                }
            }
        }
        roots.forEach { walk(File(it), 0) }
        return out
    }

    private fun hasPermission(): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        @Suppress("DEPRECATION")
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMISSION) js("window.onPermission && window.onPermission(${hasPermission()})")
    }

    private fun mime(path: String) = when (path.substringAfterLast('.')) {
        "html" -> "text/html"; "css" -> "text/css"; "js" -> "application/javascript"
        "woff2" -> "font/woff2"; "svg" -> "image/svg+xml"; "png" -> "image/png"; "json" -> "application/json"
        else -> "application/octet-stream"
    }

    // ---------------- Lo que la interfaz puede pedir ----------------

    inner class Bridge {
        @JavascriptInterface fun hasPermission(): Boolean = this@MainActivity.hasPermission()

        @JavascriptInterface fun requestPermission() = runOnUiThread {
            val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
            requestPermissions(arrayOf(p), REQ_PERMISSION)
        }

        @JavascriptInterface fun volumes(): String = this@MainActivity.volumes().toString()

        @JavascriptInterface fun list(path: String): String = try { listDir(path).toString() }
            catch (e: Exception) { JSONObject().put("path", path).put("error", e.message ?: "error").toString() }

        /** Busca en segundo plano y responde con window.onScan(id, resultado). */
        @JavascriptInterface fun scan(id: String, rootsJson: String) {
            thread(name = "busqueda") {
                val roots = JSONArray(rootsJson).let { a -> (0 until a.length()).map { a.getString(it) } }
                val result = try { scanRoots(roots).toString() } catch (e: Exception) { "[]" }
                js("window.onScan(${JSONObject.quote(id)}, ${JSONObject.quote(result)})")
            }
        }

        @JavascriptInterface fun getSettings(): String = JSONObject()
            .put(Prefs.DV_CONVERT, settings.getBoolean(Prefs.DV_CONVERT, true))
            .put(Prefs.MATCH_FPS, settings.getBoolean(Prefs.MATCH_FPS, true))
            .put(Prefs.AUDIO_LANG, settings.getString(Prefs.AUDIO_LANG, "es"))
            .put(Prefs.SUBS, settings.getString(Prefs.SUBS, "forced"))
            .put("dvAvailable", DvConverter.available)
            .toString()

        @JavascriptInterface fun setSetting(key: String, value: String) {
            val e = settings.edit()
            when (key) {
                Prefs.DV_CONVERT, Prefs.MATCH_FPS -> e.putBoolean(key, value == "true")
                Prefs.AUDIO_LANG, Prefs.SUBS -> e.putString(key, value)
                else -> return
            }
            e.apply()
        }

        /** Posición guardada, duración y si está vista, de todas las películas. */
        @JavascriptInterface fun positions(): String {
            val out = JSONObject()
            for ((k, v) in positions.all) {
                when {
                    k.startsWith(Prefs.SEEN_PREFIX) -> obj(out, k.removePrefix(Prefs.SEEN_PREFIX)).put("seen", v == true)
                    k.startsWith(Prefs.DURATION_PREFIX) -> obj(out, k.removePrefix(Prefs.DURATION_PREFIX)).put("dur", (v as? Long) ?: 0L)
                    else -> obj(out, k).put("pos", (v as? Long) ?: 0L)
                }
            }
            return out.toString()
        }
        private fun obj(o: JSONObject, k: String): JSONObject = o.optJSONObject(k) ?: JSONObject().also { o.put(k, it) }

        @JavascriptInterface fun setSeen(path: String, seen: Boolean) {
            val e = positions.edit()
            if (seen) e.putBoolean(Prefs.SEEN_PREFIX + path, true).remove(path) else e.remove(Prefs.SEEN_PREFIX + path)
            e.apply()
        }

        @JavascriptInterface fun play(path: String, title: String, startMs: Double) = runOnUiThread {
            startActivity(Intent(this@MainActivity, PlayerActivity::class.java)
                .putExtra("path", path).putExtra("title", title).putExtra("start", startMs.toLong()))
        }

        /** Clave de TMDB guardada en un archivo tmdb_key.txt en la raíz de algún disco (para no teclearla). */
        @JavascriptInterface fun readKeyFile(): String {
            val arr = this@MainActivity.volumes()
            for (i in 0 until arr.length()) {
                val dir = File(arr.getJSONObject(i).getString("path"))
                for (n in listOf("tmdb_key.txt", "tmdb.txt", "TMDB_KEY.txt")) {
                    val f = File(dir, n)
                    if (f.isFile && f.length() < 4096) return try { f.readText().trim() } catch (e: Exception) { "" }
                }
            }
            return ""
        }

        /** Capítulos del archivo: [{"t": milisegundos, "title": "..."}] */
        @JavascriptInterface fun chapters(path: String): String {
            val out = JSONArray()
            MkvChapters.read(File(path)).forEach { out.put(JSONObject().put("t", it.startMs).put("title", it.title)) }
            return out.toString()
        }

        @JavascriptInterface fun version(): String = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) { "" }
    }
}

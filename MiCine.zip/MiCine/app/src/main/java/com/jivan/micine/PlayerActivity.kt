package com.jivan.micine

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.util.Util
import androidx.media3.exoplayer.DecoderReuseEvaluation
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.ui.PlayerView
import java.io.File
import kotlin.math.abs
import kotlin.concurrent.thread

/**
 * Reproductor a pantalla completa.
 *  - Vídeo: sin recomprimir. HDR10, Dolby Vision 5/8 y el perfil 7 convertido a 8.1 al vuelo.
 *  - Sonido: lo que admite la tele sale sin descodificar por HDMI (Atmos, TrueHD...). Lo que no
 *    (DTS en la LG C5) lo descodifica FFmpeg y sale como PCM multicanal, sin pérdida.
 *  - Ajusta la frecuencia de la pantalla a la de la película (23,976 Hz, 24, 25...).
 */
@OptIn(UnstableApi::class)
class PlayerActivity : Activity(), VideoInfoListener {

    private lateinit var player: ExoPlayer
    private lateinit var view: PlayerView
    private lateinit var info: TextView
    private lateinit var notice: TextView
    private val main = Handler(Looper.getMainLooper())

    private var path = ""
    private var title = ""
    private var started = false
    private var released = false

    // Datos para el panel de información
    private var dvText: String? = null
    private var videoText = ""
    private var videoDecoder = ""
    private var audioText = ""
    private var audioOut = ""
    private var fpsText = ""

    // Capítulos
    private var chapters: List<MkvChapters.Chapter> = emptyList()
    private lateinit var chapterPanel: LinearLayout
    private lateinit var chapterTitle: TextView
    private lateinit var chapterScroll: HorizontalScrollView
    private lateinit var chapterRow: LinearLayout
    private var chapterSel = 0

    private val settings by lazy { getSharedPreferences(Prefs.SETTINGS, Context.MODE_PRIVATE) }
    private val positions by lazy { getSharedPreferences(Prefs.POSITIONS, Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        path = intent.getStringExtra("path") ?: run { finish(); return }
        title = intent.getStringExtra("title") ?: File(path).nameWithoutExtension
        val startMs = intent.getLongExtra("start", 0L)

        buildViews()

        val dvConvert = settings.getBoolean(Prefs.DV_CONVERT, true)
        val matchFps = settings.getBoolean(Prefs.MATCH_FPS, true)

        // Sonido: lo que admite la tele (Atmos, TrueHD, Dolby Digital...) sale tal cual por HDMI.
        // Lo que no (DTS en la LG C5), lo descodifica FFmpeg y sale como PCM multicanal sin pérdida.
        val renderers = DefaultRenderersFactory(this)
        renderers.setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        renderers.setEnableDecoderFallback(true)

        val trackSelector = DefaultTrackSelector(this)
        trackSelector.setParameters(trackParameters(trackSelector))

        val mediaSources = DefaultMediaSourceFactory(DefaultDataSource.Factory(this), DvExtractorsFactory(dvConvert, this))

        player = ExoPlayer.Builder(this, renderers)
            .setTrackSelector(trackSelector)
            .setMediaSourceFactory(mediaSources)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(30_000)
            .build()
        player.setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
            true,
        )
        // El cambio de frecuencia lo hace la propia app (ver switchDisplayMode).
        player.setVideoChangeFrameRateStrategy(
            if (matchFps) C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_OFF else C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_ONLY_IF_SEAMLESS,
        )
        player.addAnalyticsListener(analytics)
        player.addListener(playerListener)
        view.player = player

        player.setMediaItem(MediaItem.fromUri(Uri.fromFile(File(path))), startMs)
        player.playWhenReady = false
        player.prepare()

        if (matchFps) {
            // Espera a conocer los fotogramas por segundo para cambiar la pantalla antes de empezar.
            main.postDelayed({ if (!started) startPlayback(0) }, 3000)
        } else {
            startPlayback(0)
        }
        main.postDelayed(saveTicker, 15_000)

        // Capítulos del MKV (solo se lee la cabecera del archivo).
        thread(name = "capitulos") {
            val ch = MkvChapters.read(File(path))
            main.post { if (!released) onChaptersLoaded(ch) }
        }
    }

    private fun trackParameters(ts: DefaultTrackSelector): DefaultTrackSelector.Parameters {
        val b = ts.buildUponParameters()
        when (settings.getString(Prefs.AUDIO_LANG, "es")) {
            "es" -> b.setPreferredAudioLanguage("es")
            else -> b.setPreferredAudioLanguage(null) // la pista marcada por defecto en el archivo
        }
        when (settings.getString(Prefs.SUBS, "forced")) {
            "es" -> b.setPreferredTextLanguage("es")
            "off" -> b.setPreferredTextLanguage(null)
                .setIgnoredTextSelectionFlags(C.SELECTION_FLAG_DEFAULT or C.SELECTION_FLAG_FORCED)
            else -> b.setPreferredTextLanguage(null) // solo subtítulos forzados (carteles, idiomas extranjeros)
                .setIgnoredTextSelectionFlags(C.SELECTION_FLAG_DEFAULT)
        }
        return b.build()
    }

    // ---------------- Vistas ----------------

    private fun buildViews() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        view = PlayerView(this)
        view.setShowSubtitleButton(true)
        view.setShowNextButton(false)
        view.setShowPreviousButton(false)
        view.setControllerShowTimeoutMs(4000)
        view.setControllerAutoShow(false)
        view.keepScreenOn = true
        root.addView(view, FrameLayout.LayoutParams(-1, -1))

        info = TextView(this).apply {
            setTextColor(Color.parseColor("#F3E7D3"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setLineSpacing(0f, 1.25f)
            setBackgroundColor(Color.parseColor("#C8140F0B"))
            setPadding(dp(22), dp(16), dp(22), dp(16))
            visibility = View.GONE
        }
        root.addView(info, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply {
            setMargins(dp(40), dp(32), dp(40), 0)
        })

        notice = TextView(this).apply {
            setTextColor(Color.parseColor("#F3E7D3"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            setBackgroundColor(Color.parseColor("#D9140F0B"))
            setPadding(dp(26), dp(14), dp(26), dp(14))
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        root.addView(notice, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        // Panel de capítulos, abajo
        chapterPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(40), dp(18), dp(40), dp(26))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#00140F0B"), Color.parseColor("#E6140F0B"), Color.parseColor("#F2140F0B")))
            visibility = View.GONE
        }
        chapterTitle = TextView(this).apply {
            setTextColor(Color.parseColor("#F3E7D3"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(0, dp(18), 0, dp(10))
        }
        chapterPanel.addView(chapterTitle)
        chapterScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; isFocusable = false }
        chapterRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chapterScroll.addView(chapterRow)
        chapterPanel.addView(chapterScroll)
        root.addView(chapterPanel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showNotice(text: String, ms: Long = 3000) {
        notice.text = text
        notice.visibility = View.VISIBLE
        main.removeCallbacks(hideNotice)
        main.postDelayed(hideNotice, ms)
    }
    private val hideNotice = Runnable { notice.visibility = View.GONE }

    private fun refreshInfo() {
        val lines = ArrayList<String>()
        lines += title
        val v = listOfNotNull(videoText.ifEmpty { null }, dvText, fpsText.ifEmpty { null }).joinToString("  ·  ")
        if (v.isNotEmpty()) lines += "Vídeo: $v"
        if (videoDecoder.isNotEmpty()) lines += "Decodificador: $videoDecoder"
        val a = listOf(audioText, audioOut).filter { it.isNotEmpty() }.joinToString("  →  ")
        if (a.isNotEmpty()) lines += "Sonido: $a"
        if (chapters.isNotEmpty()) lines += "Capítulos: ${chapters.size}  (pulsa abajo para verlos)"
        info.text = lines.joinToString("\n")
    }

    private fun showInfo(ms: Long) {
        refreshInfo()
        info.visibility = View.VISIBLE
        main.removeCallbacks(hideInfo)
        if (ms > 0) main.postDelayed(hideInfo, ms)
    }
    private val hideInfo = Runnable { info.visibility = View.GONE }

    // ---------------- Capítulos ----------------

    private fun onChaptersLoaded(ch: List<MkvChapters.Chapter>) {
        chapters = ch
        if (ch.isEmpty()) return
        // Marcas en la barra de progreso (la del principio no hace falta).
        val marks = ch.map { it.startMs }.filter { it > 0 }.toLongArray()
        try { view.setExtraAdGroupMarkers(marks, BooleanArray(marks.size)) } catch (e: Exception) {}
        chapterRow.removeAllViews()
        ch.forEachIndexed { i, c -> chapterRow.addView(chapterCard(i, c)) }
        refreshInfo()
    }

    private fun chapterCard(i: Int, c: MkvChapters.Chapter): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        card.addView(TextView(this).apply {
            text = (i + 1).toString()
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = Typeface.create("serif", Typeface.BOLD)
        })
        card.addView(TextView(this).apply {
            text = c.title
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        card.addView(TextView(this).apply {
            text = hms(c.startMs)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        })
        card.layoutParams = LinearLayout.LayoutParams(dp(190), -2).apply { marginEnd = dp(12) }
        return card
    }

    private fun hms(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) String.format("%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
        else String.format("%d:%02d", s / 60, s % 60)
    }

    /** Capítulo en curso según la posición de la película. */
    private fun currentChapter(): Int {
        val p = player.currentPosition + 500
        var idx = 0
        chapters.forEachIndexed { i, c -> if (c.startMs <= p) idx = i }
        return idx
    }

    private fun paintChapters() {
        for (i in 0 until chapterRow.childCount) {
            val card = chapterRow.getChildAt(i) as LinearLayout
            val selected = i == chapterSel
            card.background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor(if (selected) "#E8C27A" else "#2B211A"))
            }
            val ink = Color.parseColor(if (selected) "#15110E" else "#F3E7D3")
            val soft = Color.parseColor(if (selected) "#4A3826" else "#B3A493")
            (card.getChildAt(0) as TextView).setTextColor(ink)
            (card.getChildAt(1) as TextView).setTextColor(ink)
            (card.getChildAt(2) as TextView).setTextColor(soft)
        }
        val c = chapters[chapterSel]
        chapterTitle.text = "Capítulos  ·  ${chapterSel + 1} de ${chapters.size}  ·  ${c.title}"
        chapterRow.getChildAt(chapterSel)?.let { v ->
            chapterScroll.post { chapterScroll.smoothScrollTo(maxOf(0, v.left - dp(160)), 0) }
        }
    }

    private fun openChapters() {
        if (chapters.isEmpty()) return
        view.hideController()
        hideInfo.run()
        chapterSel = currentChapter()
        chapterPanel.visibility = View.VISIBLE
        paintChapters()
    }

    private fun closeChapters() { chapterPanel.visibility = View.GONE }

    private fun goToChapter(i: Int) {
        if (chapters.isEmpty()) return
        val idx = i.coerceIn(0, chapters.size - 1)
        player.seekTo(chapters[idx].startMs)
        showNotice("Capítulo ${idx + 1}  ·  ${chapters[idx].title}", 2500)
    }

    /** Siguiente o anterior. «Anterior» en los primeros segundos de un capítulo va al de antes. */
    private fun jumpChapter(dir: Int) {
        if (chapters.isEmpty()) return
        val cur = currentChapter()
        if (dir > 0) { if (cur + 1 < chapters.size) goToChapter(cur + 1) }
        else {
            val intoChapter = player.currentPosition - chapters[cur].startMs
            goToChapter(if (intoChapter > 5000 || cur == 0) cur else cur - 1)
        }
    }

    // ---------------- Frecuencia de la pantalla ----------------

    override fun onDolbyVision(description: String) {
        main.post { dvText = description; refreshInfo() }
    }

    override fun onFrameRate(fps: Float) {
        main.post {
            fpsText = String.format("%.3f", fps).trimEnd('0').trimEnd(',', '.').replace('.', ',') + " fps"
            refreshInfo()
            if (!started && settings.getBoolean(Prefs.MATCH_FPS, true)) {
                val changed = switchDisplayMode(fps)
                startPlayback(if (changed) 2200 else 0)
            }
        }
    }

    /** Elige el modo de pantalla con la misma resolución y la frecuencia de la película (o su doble). */
    private fun switchDisplayMode(fps: Float): Boolean {
        val display = window.decorView.display ?: return false
        val current = display.mode
        val same = display.supportedModes.filter {
            it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight
        }
        val best = same.firstOrNull { abs(it.refreshRate - fps) < 0.02f }
            ?: same.firstOrNull { abs(it.refreshRate - 2 * fps) < 0.04f }
            ?: return false
        if (best.modeId == current.modeId) return false
        val lp = window.attributes
        lp.preferredDisplayModeId = best.modeId
        window.attributes = lp
        return true
    }

    private fun startPlayback(delayMs: Long) {
        if (started) return
        started = true
        if (delayMs > 0) showNotice("Ajustando la pantalla a la película…", delayMs)
        main.postDelayed({
            if (!released) {
                player.playWhenReady = true
                showInfo(7000)
            }
        }, delayMs)
    }

    // ---------------- Información de las pistas ----------------

    private val analytics = object : AnalyticsListener {
        override fun onVideoInputFormatChanged(
            eventTime: AnalyticsListener.EventTime,
            format: Format,
            decoderReuseEvaluation: DecoderReuseEvaluation?,
        ) {
            val res = if (format.width > 0) "${format.width}×${format.height}" else ""
            val hdr = when {
                format.sampleMimeType == MimeTypes.VIDEO_DOLBY_VISION -> ""
                format.colorInfo?.colorTransfer == C.COLOR_TRANSFER_ST2084 -> "HDR10"
                format.colorInfo?.colorTransfer == C.COLOR_TRANSFER_HLG -> "HLG"
                else -> "SDR"
            }
            videoText = listOf(res, hdr).filter { it.isNotEmpty() }.joinToString("  ·  ")
            refreshInfo()
        }

        override fun onVideoDecoderInitialized(
            eventTime: AnalyticsListener.EventTime,
            decoderName: String,
            initializedTimestampMs: Long,
            initializationDurationMs: Long,
        ) {
            videoDecoder = decoderName
            refreshInfo()
        }

        override fun onAudioInputFormatChanged(
            eventTime: AnalyticsListener.EventTime,
            format: Format,
            decoderReuseEvaluation: DecoderReuseEvaluation?,
        ) {
            audioText = describeAudio(format)
            refreshInfo()
        }

        override fun onAudioTrackInitialized(
            eventTime: AnalyticsListener.EventTime,
            audioTrackConfig: AudioSink.AudioTrackConfig,
        ) {
            audioOut = if (Util.isEncodingLinearPcm(audioTrackConfig.encoding)) "descodificado por la SHIELD (PCM, sin pérdida)"
            else "sin descodificar (sale tal cual por HDMI)"
            refreshInfo()
        }
    }

    private fun describeAudio(f: Format): String {
        val name = when (f.sampleMimeType) {
            MimeTypes.AUDIO_TRUEHD -> "Dolby TrueHD"
            MimeTypes.AUDIO_E_AC3_JOC -> "Dolby Digital Plus Atmos"
            MimeTypes.AUDIO_E_AC3 -> "Dolby Digital Plus"
            MimeTypes.AUDIO_AC3 -> "Dolby Digital"
            MimeTypes.AUDIO_AC4 -> "Dolby AC-4"
            MimeTypes.AUDIO_DTS_HD -> "DTS-HD"
            MimeTypes.AUDIO_DTS_X -> "DTS:X"
            MimeTypes.AUDIO_DTS -> "DTS"
            MimeTypes.AUDIO_DTS_EXPRESS -> "DTS Express"
            MimeTypes.AUDIO_FLAC -> "FLAC"
            MimeTypes.AUDIO_AAC -> "AAC"
            MimeTypes.AUDIO_RAW -> "PCM"
            else -> f.sampleMimeType?.substringAfter('/')?.uppercase() ?: "?"
        }
        val ch = when (f.channelCount) { 8 -> "7.1"; 6 -> "5.1"; 2 -> "2.0"; 1 -> "1.0"; else -> if (f.channelCount > 0) "${f.channelCount} canales" else "" }
        val lang = f.language?.let { java.util.Locale(it).getDisplayLanguage(java.util.Locale("es")).replaceFirstChar { c -> c.uppercase() } }
        val label = f.label?.takeIf { it.isNotBlank() }
        return listOfNotNull(name, ch.ifEmpty { null }, lang, label?.let { "«$it»" }).joinToString(" ")
    }

    private val playerListener = object : Player.Listener {
        override fun onTracksChanged(tracks: Tracks) {
            // Por si alguna pista no se puede reproducir de ninguna forma.
            val audio = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
            if (audio.isNotEmpty() && audio.none { it.isSelected }) {
                showNotice("La tele no admite ninguna pista de sonido de esta película", 6000)
            }
        }

        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_ENDED) {
                positions.edit().remove(path).putBoolean(Prefs.SEEN_PREFIX + path, true).apply()
                finish()
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            showInfo(0)
            showNotice("No se puede reproducir: ${error.errorCodeName}\n${error.cause?.message ?: error.message ?: ""}", 12_000)
        }
    }

    // ---------------- Posición guardada ----------------

    private val saveTicker = object : Runnable {
        override fun run() {
            savePosition()
            main.postDelayed(this, 15_000)
        }
    }

    private fun savePosition() {
        if (released) return
        val pos = player.currentPosition
        val dur = player.duration
        if (dur <= 0) return
        val e = positions.edit().putLong(Prefs.DURATION_PREFIX + path, dur)
        when {
            dur - pos < 4 * 60_000 -> e.remove(path).putBoolean(Prefs.SEEN_PREFIX + path, true) // casi terminada: vista
            pos > 60_000 -> e.putLong(path, pos)
        }
        e.apply()
    }

    // ---------------- Mando ----------------

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        // Saltar de capítulo con los botones de siguiente / anterior (o canal arriba / abajo).
        if (chapters.isNotEmpty() && (code == KeyEvent.KEYCODE_MEDIA_NEXT || code == KeyEvent.KEYCODE_MEDIA_PREVIOUS ||
                code == KeyEvent.KEYCODE_CHANNEL_UP || code == KeyEvent.KEYCODE_CHANNEL_DOWN)) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                jumpChapter(if (code == KeyEvent.KEYCODE_MEDIA_NEXT || code == KeyEvent.KEYCODE_CHANNEL_UP) 1 else -1)
            }
            return true
        }
        if (isMediaKey(code)) return view.dispatchMediaKeyEvent(event) || super.dispatchKeyEvent(event)
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        // Con el panel de capítulos abierto, el mando lo maneja a él.
        if (chapterPanel.visibility == View.VISIBLE) {
            when (code) {
                KeyEvent.KEYCODE_DPAD_LEFT -> { if (chapterSel > 0) { chapterSel--; paintChapters() } }
                KeyEvent.KEYCODE_DPAD_RIGHT -> { if (chapterSel < chapters.size - 1) { chapterSel++; paintChapters() } }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { goToChapter(chapterSel); closeChapters() }
                KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> closeChapters()
            }
            return true
        }
        if (code == KeyEvent.KEYCODE_BACK) {
            if (info.visibility == View.VISIBLE) { hideInfo.run(); return true }
            if (view.isControllerFullyVisible) { view.hideController(); return true }
            finish(); return true
        }
        if (!view.isControllerFullyVisible) {
            when (code) {
                KeyEvent.KEYCODE_DPAD_LEFT -> { player.seekBack(); view.showController(); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT -> { player.seekForward(); view.showController(); return true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    if (player.isPlaying) player.pause() else player.play()
                    view.showController(); return true
                }
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_INFO -> {
                    if (info.visibility == View.VISIBLE) hideInfo.run() else showInfo(0); return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (chapters.isNotEmpty()) openChapters() else view.showController(); return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun isMediaKey(code: Int) = code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || code == KeyEvent.KEYCODE_MEDIA_PLAY ||
        code == KeyEvent.KEYCODE_MEDIA_PAUSE || code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD ||
        code == KeyEvent.KEYCODE_MEDIA_REWIND || code == KeyEvent.KEYCODE_MEDIA_STOP

    // ---------------- Ciclo de vida ----------------

    override fun onPause() {
        super.onPause()
        if (!released) { savePosition(); player.pause() }
    }

    override fun onStop() {
        super.onStop()
        // Al salir (botón de inicio, apagar la tele...) se guarda y se cierra; se reanuda desde la biblioteca.
        if (!isChangingConfigurations) finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        main.removeCallbacksAndMessages(null)
        if (!released && this::player.isInitialized) {
            savePosition()
            released = true
            player.release()
        }
    }
}

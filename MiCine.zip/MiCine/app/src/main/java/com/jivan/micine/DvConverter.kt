package com.jivan.micine

/**
 * Puente con la librería nativa libdvconv.so (Rust + libdovi, la librería de dovi_tool).
 * Convierte cada fotograma de Dolby Vision perfil 7 a perfil 8.1:
 * quita la capa de mejora y adapta los metadatos. La imagen base no se toca.
 */
object DvConverter {

    /** false si la librería no se ha podido cargar: entonces el perfil 7 se ve como HDR10. */
    val available: Boolean = try {
        System.loadLibrary("dvconv")
        true
    } catch (t: Throwable) {
        false
    }

    /** Fotograma convertido, o null si no había nada que cambiar. nalLengthSize = 0: códigos de inicio. */
    @JvmStatic
    external fun nativeConvert(input: ByteArray, length: Int, nalLengthSize: Int): ByteArray?

    /** Perfil de Dolby Vision del fotograma (0 si no lleva metadatos legibles). */
    @JvmStatic
    external fun nativeProfile(input: ByteArray, length: Int, nalLengthSize: Int): Int

    fun convert(input: ByteArray, length: Int): ByteArray? =
        if (available) try { nativeConvert(input, length, 0) } catch (t: Throwable) { null } else null

    fun profile(input: ByteArray, length: Int): Int =
        if (available) try { nativeProfile(input, length, 0) } catch (t: Throwable) { 0 } else 0
}

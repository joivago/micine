package com.jivan.micine

import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.ColorInfo
import androidx.media3.common.DataReader
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.ParsableByteArray
import androidx.media3.common.util.UnstableApi
import androidx.media3.container.NalUnitUtil
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.Extractor
import androidx.media3.extractor.ExtractorInput
import androidx.media3.extractor.ExtractorOutput
import androidx.media3.extractor.ExtractorsFactory
import androidx.media3.extractor.PositionHolder
import androidx.media3.extractor.SeekMap
import androidx.media3.extractor.SniffFailure
import androidx.media3.extractor.TrackOutput
import androidx.media3.extractor.text.SubtitleParser
import java.io.EOFException

/** Lo que el reproductor cuenta sobre el vídeo mientras lo lee. */
interface VideoInfoListener {
    /** Texto para el panel de información, p. ej. «Dolby Vision perfil 7 → 8.1». */
    fun onDolbyVision(description: String)
    /** Fotogramas por segundo estimados a partir de los primeros fotogramas. */
    fun onFrameRate(fps: Float)
}

/**
 * Igual que los lectores de Media3 de siempre, pero cada pista de vídeo pasa por [DvTrackOutput].
 */
@OptIn(UnstableApi::class)
class DvExtractorsFactory(
    private val convertProfile7: Boolean,
    private val listener: VideoInfoListener,
) : ExtractorsFactory {

    private val inner = DefaultExtractorsFactory().setConstantBitrateSeekingEnabled(true)

    override fun createExtractors(): Array<Extractor> =
        inner.createExtractors().map { wrap(it) }.toTypedArray()

    override fun createExtractors(uri: Uri, responseHeaders: Map<String, List<String>>): Array<Extractor> =
        inner.createExtractors(uri, responseHeaders).map { wrap(it) }.toTypedArray()

    override fun setSubtitleParserFactory(subtitleParserFactory: SubtitleParser.Factory): ExtractorsFactory {
        inner.setSubtitleParserFactory(subtitleParserFactory)
        return this
    }

    @Deprecated("Deprecated in Java")
    override fun experimentalSetTextTrackTranscodingEnabled(textTrackTranscodingEnabled: Boolean): ExtractorsFactory {
        @Suppress("DEPRECATION")
        inner.experimentalSetTextTrackTranscodingEnabled(textTrackTranscodingEnabled)
        return this
    }

    override fun experimentalSetCodecsToParseWithinGopSampleDependencies(
        codecsToParseWithinGopSampleDependencies: Int,
    ): ExtractorsFactory {
        inner.experimentalSetCodecsToParseWithinGopSampleDependencies(codecsToParseWithinGopSampleDependencies)
        return this
    }

    private fun wrap(e: Extractor): Extractor = WrappingExtractor(e, convertProfile7, listener)
}

@OptIn(UnstableApi::class)
internal class WrappingExtractor(
    private val delegate: Extractor,
    private val convertProfile7: Boolean,
    private val listener: VideoInfoListener,
) : Extractor {
    override fun sniff(input: ExtractorInput): Boolean = delegate.sniff(input)
    override fun getSniffFailureDetails(): List<SniffFailure> = delegate.sniffFailureDetails
    private var output: WrappingOutput? = null

    override fun init(output: ExtractorOutput) {
        val w = WrappingOutput(output, convertProfile7, listener)
        this.output = w
        delegate.init(w)
    }
    override fun read(input: ExtractorInput, seekPosition: PositionHolder): Int = delegate.read(input, seekPosition)
    override fun seek(position: Long, timeUs: Long) {
        output?.discardPending()   // un fotograma a medias de antes del salto no debe mezclarse con el siguiente
        delegate.seek(position, timeUs)
    }
    override fun release() = delegate.release()
    override fun getUnderlyingImplementation(): Extractor = delegate.underlyingImplementation
}

@OptIn(UnstableApi::class)
internal class WrappingOutput(
    private val delegate: ExtractorOutput,
    private val convertProfile7: Boolean,
    private val listener: VideoInfoListener,
) : ExtractorOutput {
    private val wrapped = HashMap<Int, DvTrackOutput>()

    fun discardPending() { wrapped.values.forEach { it.discardPending() } }

    override fun track(id: Int, type: Int): TrackOutput {
        val out = delegate.track(id, type)
        if (type != C.TRACK_TYPE_VIDEO) return out
        return wrapped.getOrPut(id) { DvTrackOutput(out, convertProfile7, listener) }
    }

    override fun endTracks() = delegate.endTracks()
    override fun seekMap(seekMap: SeekMap) = delegate.seekMap(seekMap)
}

/**
 * Pista de vídeo que:
 *  - con Dolby Vision perfil 7 (remux de UHD Blu-ray) convierte cada fotograma a perfil 8.1,
 *    o, si la conversión está desactivada, lo presenta como HEVC HDR10 (la capa base);
 *  - con HEVC HDR sin configuración Dolby Vision en el MKV, mira el primer fotograma por si
 *    lleva metadatos Dolby Vision (MKV antiguos) y entonces lo presenta como Dolby Vision;
 *  - mide los fotogramas por segundo para ajustar la frecuencia de la pantalla.
 */
@OptIn(UnstableApi::class)
internal class DvTrackOutput(
    private val delegate: TrackOutput,
    private val convertProfile7: Boolean,
    private val listener: VideoInfoListener,
) : TrackOutput {

    private enum class Mode { PASS, CONVERT, PROBE }

    private var mode = Mode.PASS
    private var pendingFormat: Format? = null

    // Fotograma en curso (solo se guarda en memoria cuando hay que tocarlo).
    private var buf = ByteArray(1 shl 20)
    private var len = 0
    private val partOf = ArrayList<IntArray>() // [parte, inicio, longitud]

    // Medida de fotogramas por segundo
    private val times = ArrayList<Long>(64)
    private var fpsReported = false

    override fun format(original: Format) {
        val format = withBitstreamColor(original)
        val mime = format.sampleMimeType
        val profile = dvProfile(format.codecs)
        when {
            mime == MimeTypes.VIDEO_DOLBY_VISION && profile == 7 -> {
                if (convertProfile7 && DvConverter.available) {
                    mode = Mode.CONVERT
                    delegate.format(format.buildUpon().setCodecs(toProfile8(format.codecs!!)).build())
                    listener.onDolbyVision("Dolby Vision perfil 7 → 8.1 (convertido al vuelo)")
                } else {
                    // Sin conversión: la SHIELD no reproduce el perfil 7, así que se usa la capa base HDR10.
                    mode = Mode.PASS
                    delegate.format(format.buildUpon().setSampleMimeType(MimeTypes.VIDEO_H265).setCodecs(null).build())
                    listener.onDolbyVision("Perfil 7 mostrado como HDR10 (conversión desactivada)")
                }
            }
            mime == MimeTypes.VIDEO_DOLBY_VISION -> {
                mode = Mode.PASS
                delegate.format(format)
                listener.onDolbyVision("Dolby Vision perfil $profile")
            }
            mime == MimeTypes.VIDEO_H265 && format.colorInfo?.colorTransfer == C.COLOR_TRANSFER_ST2084 -> {
                // HDR10... o Dolby Vision sin configuración en el MKV. Se decide con el primer fotograma.
                mode = Mode.PROBE
                pendingFormat = format
            }
            else -> {
                mode = Mode.PASS
                delegate.format(format)
            }
        }
    }

    override fun durationUs(durationUs: Long) = delegate.durationUs(durationUs)

    /**
     * Muchos MKV no llevan los datos de color en el contenedor, solo dentro del vídeo (en el SPS).
     * Media3 1.9 solo mira el contenedor y los daría por SDR; aquí se leen del propio vídeo.
     */
    private fun withBitstreamColor(f: Format): Format {
        val mime = f.sampleMimeType
        if (mime != MimeTypes.VIDEO_H265 && mime != MimeTypes.VIDEO_DOLBY_VISION) return f
        val known = f.colorInfo?.colorTransfer
        if (known != null && known != Format.NO_VALUE) return f
        try {
            for (data in f.initializationData) {
                var i = 0
                while (i + 4 < data.size) {
                    // Busca «00 00 01» y mira si la unidad que empieza ahí es un SPS (tipo 33).
                    if (data[i].toInt() == 0 && data[i + 1].toInt() == 0 && data[i + 2].toInt() == 1) {
                        val start = i + 3
                        var end = start
                        while (end + 2 < data.size && !(data[end].toInt() == 0 && data[end + 1].toInt() == 0 &&
                                (data[end + 2].toInt() == 1 || (end + 3 < data.size && data[end + 2].toInt() == 0 && data[end + 3].toInt() == 1)))) end++
                        if (end + 2 >= data.size) end = data.size
                        if ((data[start].toInt() shr 1) and 0x3F == 33) {
                            val sps = NalUnitUtil.parseH265SpsNalUnit(data, start, end, null)
                            if (sps.colorTransfer != Format.NO_VALUE) {
                                val ci = (f.colorInfo?.buildUpon() ?: ColorInfo.Builder())
                                    .setColorSpace(sps.colorSpace)
                                    .setColorRange(sps.colorRange)
                                    .setColorTransfer(sps.colorTransfer)
                                    .setLumaBitdepth(sps.bitDepthLumaMinus8 + 8)
                                    .setChromaBitdepth(sps.bitDepthChromaMinus8 + 8)
                                    .build()
                                return f.buildUpon().setColorInfo(ci).build()
                            }
                        }
                        i = end
                    } else i++
                }
            }
        } catch (e: Exception) {
        }
        return f
    }

    override fun sampleData(input: DataReader, length: Int, allowEndOfInput: Boolean, sampleDataPart: Int): Int {
        if (mode == Mode.PASS) return delegate.sampleData(input, length, allowEndOfInput, sampleDataPart)
        ensure(length)
        val n = input.read(buf, len, length)
        if (n == C.RESULT_END_OF_INPUT) {
            if (allowEndOfInput) return C.RESULT_END_OF_INPUT
            throw EOFException()
        }
        addPart(sampleDataPart, n)
        return n
    }

    override fun sampleData(data: ParsableByteArray, length: Int, sampleDataPart: Int) {
        if (mode == Mode.PASS) { delegate.sampleData(data, length, sampleDataPart); return }
        ensure(length)
        data.readBytes(buf, len, length)
        addPart(sampleDataPart, length)
    }

    override fun sampleMetadata(timeUs: Long, flags: Int, size: Int, offset: Int, cryptoData: TrackOutput.CryptoData?) {
        measureFps(timeUs)
        if (mode == Mode.PASS) { delegate.sampleMetadata(timeUs, flags, size, offset, cryptoData); return }

        if (mode == Mode.PROBE) {
            val main = mainBytes()
            val p = if (main != null) DvConverter.profile(main, main.size) else 0
            val f = pendingFormat!!
            pendingFormat = null
            mode = when {
                p == 7 && convertProfile7 && DvConverter.available -> {
                    delegate.format(f.buildUpon().setSampleMimeType(MimeTypes.VIDEO_DOLBY_VISION).setCodecs("dvhe.08.06").build())
                    listener.onDolbyVision("Dolby Vision perfil 7 → 8.1 (convertido al vuelo)")
                    Mode.CONVERT
                }
                p == 8 -> {
                    delegate.format(f.buildUpon().setSampleMimeType(MimeTypes.VIDEO_DOLBY_VISION).setCodecs("dvhe.08.06").build())
                    listener.onDolbyVision("Dolby Vision perfil 8")
                    Mode.PASS
                }
                else -> {
                    delegate.format(f)
                    if (p == 7) listener.onDolbyVision("Perfil 7 mostrado como HDR10 (conversión desactivada)")
                    Mode.PASS
                }
            }
            if (mode == Mode.PASS) { flushOriginal(); delegate.sampleMetadata(timeUs, flags, size, offset, cryptoData); return }
        }

        // Mode.CONVERT
        if (offset != 0 || cryptoData != null || len != size) {
            // Caso raro que no se sabe tratar con seguridad: el fotograma sigue tal cual.
            flushOriginal(); delegate.sampleMetadata(timeUs, flags, size, offset, cryptoData); return
        }
        val main = mainBytes()
        val converted = if (main != null) DvConverter.convert(main, main.size) else null
        if (converted == null) {
            flushOriginal(); delegate.sampleMetadata(timeUs, flags, size, offset, cryptoData); return
        }
        val mainLen = main!!.size
        val hasSupplemental = (flags and C.BUFFER_FLAG_HAS_SUPPLEMENTAL_DATA) != 0
        // Con datos extra (HDR10+), delante va el tamaño de la imagen en 4 bytes: hay que corregirlo.
        val first = partOf.firstOrNull()
        if (hasSupplemental) {
            val ok = first != null && first[0] == TrackOutput.SAMPLE_DATA_PART_SUPPLEMENTAL && first[2] >= 4 &&
                readInt(first[1]) == mainLen
            if (!ok) { flushOriginal(); delegate.sampleMetadata(timeUs, flags, size, offset, cryptoData); return }
            writeInt(first!![1], converted.size)
        }
        var mainWritten = false
        for (p in partOf) {
            if (p[0] == TrackOutput.SAMPLE_DATA_PART_MAIN) {
                if (!mainWritten) {
                    delegate.sampleData(ParsableByteArray(converted), converted.size, TrackOutput.SAMPLE_DATA_PART_MAIN)
                    mainWritten = true
                }
            } else {
                delegate.sampleData(ParsableByteArray(buf.copyOfRange(p[1], p[1] + p[2])), p[2], p[0])
            }
        }
        val newSize = size - mainLen + converted.size
        reset()
        delegate.sampleMetadata(timeUs, flags, newSize, 0, null)
    }

    // ---------- utilidades ----------

    private fun ensure(extra: Int) {
        if (len + extra > buf.size) buf = buf.copyOf(maxOf(buf.size * 2, len + extra))
    }

    private fun addPart(part: Int, n: Int) {
        val last = partOf.lastOrNull()
        if (last != null && last[0] == part && last[1] + last[2] == len) last[2] += n
        else partOf.add(intArrayOf(part, len, n))
        len += n
    }

    /** Bytes de la imagen principal del fotograma (sin datos extra). */
    private fun mainBytes(): ByteArray? {
        var total = 0
        for (p in partOf) if (p[0] == TrackOutput.SAMPLE_DATA_PART_MAIN) total += p[2]
        if (total == 0) return null
        val out = ByteArray(total)
        var pos = 0
        for (p in partOf) if (p[0] == TrackOutput.SAMPLE_DATA_PART_MAIN) {
            System.arraycopy(buf, p[1], out, pos, p[2]); pos += p[2]
        }
        return out
    }

    /** Entrega el fotograma tal cual llegó, respetando el orden de sus partes. */
    private fun flushOriginal() {
        for (p in partOf) delegate.sampleData(ParsableByteArray(buf.copyOfRange(p[1], p[1] + p[2])), p[2], p[0])
        reset()
    }

    private fun reset() { len = 0; partOf.clear() }

    fun discardPending() = reset()

    private fun readInt(pos: Int): Int =
        ((buf[pos].toInt() and 0xFF) shl 24) or ((buf[pos + 1].toInt() and 0xFF) shl 16) or
            ((buf[pos + 2].toInt() and 0xFF) shl 8) or (buf[pos + 3].toInt() and 0xFF)

    private fun writeInt(pos: Int, v: Int) {
        buf[pos] = (v ushr 24).toByte(); buf[pos + 1] = (v ushr 16).toByte()
        buf[pos + 2] = (v ushr 8).toByte(); buf[pos + 3] = v.toByte()
    }

    private fun measureFps(timeUs: Long) {
        if (fpsReported) return
        times.add(timeUs)
        if (times.size < 48) return
        fpsReported = true
        val sorted = times.sorted()
        val diffs = (1 until sorted.size).map { sorted[it] - sorted[it - 1] }.filter { it > 0 }.sorted()
        if (diffs.isEmpty()) return
        val median = diffs[diffs.size / 2]
        val fps = 1_000_000f / median
        val standard = floatArrayOf(23.976f, 24f, 25f, 29.97f, 30f, 50f, 59.94f, 60f)
        val snap = standard.minByOrNull { kotlin.math.abs(it - fps) }!!
        if (kotlin.math.abs(snap - fps) / snap < 0.006f) listener.onFrameRate(snap)
    }

    companion object {
        fun dvProfile(codecs: String?): Int {
            val parts = codecs?.split('.') ?: return 0
            return if (parts.size >= 2) parts[1].toIntOrNull() ?: 0 else 0
        }

        /** «dvhe.07.06» → «dvhe.08.06» */
        fun toProfile8(codecs: String): String {
            val parts = codecs.split('.').toMutableList()
            if (parts.size >= 2) parts[1] = "08"
            return parts.joinToString(".")
        }
    }
}

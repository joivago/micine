package com.jivan.micine

/** Nombres de los ajustes y de las posiciones guardadas. */
object Prefs {
    const val SETTINGS = "ajustes"
    const val POSITIONS = "posiciones"
    const val TRACKS = "pistas"          // pistas de sonido y subtítulos elegidas en cada película

    const val DV_CONVERT = "dvConvert"   // convertir Dolby Vision perfil 7 a 8.1 (por defecto sí)
    const val MATCH_FPS = "matchFps"     // ajustar la frecuencia de la pantalla (por defecto sí)
    const val AUDIO_LANG = "audioLang"   // "es" o "orig"
    const val SUBS = "subs"              // "forced", "es" u "off"

    const val SEEN_PREFIX = "visto:"
    const val DURATION_PREFIX = "dur:"
}

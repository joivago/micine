package com.jivan.micine

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSourceException
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import java.io.File
import java.io.IOException
import java.io.InterruptedIOException
import java.io.RandomAccessFile
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Lectura de las películas del disco USB en bloques grandes y por adelantado.
 *
 * El lector de Media3 pide los datos en trozos muy pequeños (a veces de unos pocos bytes), y en la
 * SHIELD cada lectura de un disco USB pasa por una capa de Android bastante lenta. En las escenas de
 * más caudal de un remux 4K eso no da abasto y la película se para unos segundos.
 * Aquí un hilo aparte lee el archivo en bloques de 2 MB y los deja preparados (hasta 32 MB) mientras
 * el reproductor va consumiendo los anteriores.
 */
@OptIn(UnstableApi::class)
class LecturaDisco private constructor(private val fallback: DataSource) : BaseDataSource(false) {

    class Factory(ctx: Context) : DataSource.Factory {
        private val other = DefaultDataSource.Factory(ctx)
        override fun createDataSource(): DataSource = LecturaDisco(other.createDataSource())
    }

    private class Chunk(val data: ByteArray, val size: Int, val error: IOException? = null)

    private var openUri: Uri? = null
    private var usingFallback = false
    private var opened = false
    private var remaining = 0L

    @Volatile private var worker: Worker? = null
    private var current: Chunk? = null
    private var pos = 0

    override fun open(dataSpec: DataSpec): Long {
        openUri = dataSpec.uri
        if (dataSpec.uri.scheme != null && dataSpec.uri.scheme != "file") {
            usingFallback = true
            return fallback.open(dataSpec)
        }
        usingFallback = false
        transferInitializing(dataSpec)
        val file = File(dataSpec.uri.path ?: throw IOException("Ruta vacía"))
        val length = file.length()
        if (dataSpec.position > length) throw DataSourceException(PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE)
        remaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) dataSpec.length else length - dataSpec.position
        val w = Worker(file, dataSpec.position, remaining)
        worker = w
        w.start()
        current = null
        pos = 0
        opened = true
        transferStarted(dataSpec)
        return remaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (usingFallback) return fallback.read(buffer, offset, length)
        if (length == 0) return 0
        if (remaining == 0L) return C.RESULT_END_OF_INPUT
        var c = current
        if (c == null || pos >= c.size) {
            val w = worker ?: return C.RESULT_END_OF_INPUT
            if (c != null) w.recycle(c.data)
            c = try { w.full.take() } catch (e: InterruptedException) { throw InterruptedIOException() }
            c.error?.let { throw it }
            if (c.size <= 0) { current = null; remaining = 0; return C.RESULT_END_OF_INPUT }
            current = c
            pos = 0
        }
        val n = minOf(length, c.size - pos, if (remaining > Int.MAX_VALUE) Int.MAX_VALUE else remaining.toInt())
        System.arraycopy(c.data, pos, buffer, offset, n)
        pos += n
        remaining -= n
        bytesTransferred(n)
        return n
    }

    override fun getUri(): Uri? = if (usingFallback) fallback.uri else openUri

    override fun close() {
        if (usingFallback) { usingFallback = false; fallback.close(); return }
        worker?.stopNow()
        worker = null
        current = null
        if (opened) { opened = false; transferEnded() }
    }

    /** Hilo que lee el archivo por delante del reproductor. Tiene su propio archivo abierto. */
    private class Worker(private val file: File, private val start: Long, private val length: Long) :
        Thread("lectura-disco") {

        val full = ArrayBlockingQueue<Chunk>(QUEUE)
        private val free = ArrayBlockingQueue<ByteArray>(QUEUE + 2)
        @Volatile private var stop = false

        init { isDaemon = true; priority = MAX_PRIORITY - 1 }

        fun recycle(b: ByteArray) { free.offer(b) }

        fun stopNow() { stop = true; full.clear(); interrupt() }

        private fun deliver(c: Chunk): Boolean {
            while (!stop) {
                try { if (full.offer(c, 200, TimeUnit.MILLISECONDS)) return true } catch (e: InterruptedException) { return false }
            }
            return false
        }

        override fun run() {
            try {
                RandomAccessFile(file, "r").use { raf ->
                    raf.seek(start)
                    var left = length
                    while (!stop && left > 0) {
                        val b = free.poll() ?: ByteArray(CHUNK)
                        val want = minOf(CHUNK.toLong(), left).toInt()
                        val t0 = System.nanoTime()
                        var got = 0
                        while (got < want) {
                            val r = raf.read(b, got, want - got)
                            if (r < 0) break
                            got += r
                        }
                        if (got > 0) Velocidad.add(got, System.nanoTime() - t0)
                        if (got == 0) break
                        left -= got
                        if (!deliver(Chunk(b, got))) return
                    }
                    deliver(Chunk(ByteArray(0), 0)) // fin
                }
            } catch (e: IOException) {
                deliver(Chunk(ByteArray(0), 0, e))
            } catch (e: Exception) {
                if (!stop) deliver(Chunk(ByteArray(0), 0, IOException(e)))
            }
        }
    }

    /** Velocidad de lectura del disco en los últimos segundos (para el registro). */
    object Velocidad {
        private var bytes = 0L
        private var nanos = 0L
        @Synchronized fun add(n: Int, ns: Long) {
            bytes += n; nanos += ns
            if (nanos > 4_000_000_000L) { bytes /= 2; nanos /= 2 } // media de los últimos segundos
        }
        /** MB/s a los que lee el disco cuando está leyendo (0 si aún no se sabe). */
        @Synchronized fun mbps(): Float = if (nanos <= 0) 0f else bytes / 1e6f / (nanos / 1e9f)
    }

    companion object {
        private const val CHUNK = 2 shl 20 // 2 MB
        private const val QUEUE = 16       // 32 MB preparados
    }
}

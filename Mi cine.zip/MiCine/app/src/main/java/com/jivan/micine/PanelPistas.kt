package com.jivan.micine

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import java.util.Locale

/**
 * Panel de sonido y subtítulos (botón de menú del mando, o los botones de subtítulos / ajustes
 * de la barra). Dos columnas: ↑ ↓ para elegir, ← → para cambiar de columna, OK para aplicar.
 *
 * Lo que se elige aquí se recuerda para esa película (ver [Recuerdo]).
 */
@OptIn(UnstableApi::class)
class PanelPistas(
    private val ctx: Activity,
    private val player: ExoPlayer,
    private val onPick: (Item) -> Unit,
    private val notice: (String) -> Unit,
) {
    /** Una pista de la lista. [group] es null en «Desactivados» (subtítulos). */
    class Item(
        val type: Int,
        val group: Tracks.Group?,
        val index: Int,
        val title: String,
        val detail: String,
        var active: Boolean,
        val playable: Boolean,
    )

    private inner class Column(name: String) {
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val header = TextView(ctx).apply {
            text = name
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(dp(4), 0, 0, dp(10))
        }
        val scroll = object : ScrollView(ctx) {
            // Crece con la lista, pero como mucho hasta media pantalla.
            override fun onMeasure(w: Int, h: Int) {
                super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(dp(330), View.MeasureSpec.AT_MOST))
            }
        }.apply { isVerticalScrollBarEnabled = false; isFocusable = false }
        val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        var items: List<Item> = emptyList()
        var row = 0

        init {
            box.addView(header)
            scroll.addView(list)
            box.addView(scroll)
        }
    }

    private val cols = arrayOf(Column("Sonido"), Column("Subtítulos"))
    private var col = 0

    val view: LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(40), dp(18), dp(40), dp(26))
        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#00140F0B"), Color.parseColor("#E6140F0B"), Color.parseColor("#F2140F0B")))
        visibility = View.GONE
    }

    init {
        view.addView(TextView(ctx).apply {
            text = "Sonido y subtítulos"
            setTextColor(Color.parseColor("#F3E7D3"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.create("serif", Typeface.BOLD)
            setPadding(0, dp(18), 0, dp(2))
        })
        view.addView(TextView(ctx).apply {
            text = "↑ ↓ elegir  ·  ← → cambiar de columna  ·  OK aplicar  ·  Atrás cerrar.   Se recuerda para esta película."
            setTextColor(Color.parseColor("#B3A493"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, 0, 0, dp(14))
        })
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        cols.forEachIndexed { i, c ->
            row.addView(c.box, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i == 0) marginEnd = dp(32) })
        }
        view.addView(row)
    }

    val isOpen get() = view.visibility == View.VISIBLE

    fun open() {
        build()
        // El cursor empieza en la pista que está sonando / en pantalla.
        cols.forEach { c -> c.row = c.items.indexOfFirst { it.active }.coerceAtLeast(0) }
        col = 0
        view.visibility = View.VISIBLE
        paint(scroll = true)
    }

    fun close() { view.visibility = View.GONE }

    /** Las pistas han cambiado (por ejemplo, al aplicar una): se vuelve a pintar. */
    fun refresh() {
        if (!isOpen) return
        build()
        cols.forEach { c -> c.row = c.row.coerceIn(0, maxOf(0, c.items.size - 1)) }
        paint(scroll = false)
    }

    fun onKey(code: Int) {
        val c = cols[col]
        when (code) {
            KeyEvent.KEYCODE_DPAD_UP -> if (c.row > 0) { c.row--; paint(true) }
            KeyEvent.KEYCODE_DPAD_DOWN -> if (c.row < c.items.size - 1) { c.row++; paint(true) }
            KeyEvent.KEYCODE_DPAD_LEFT -> if (col > 0) { col--; paint(true) }
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (col < cols.size - 1) { col++; paint(true) }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> c.items.getOrNull(c.row)?.let { pick(c, it) }
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_CAPTIONS,
            KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK -> close()
        }
    }

    private fun pick(c: Column, it: Item) {
        if (!it.playable) { notice("Esta pista no se puede reproducir en la SHIELD"); return }
        if (it.active) return
        select(player, it)
        c.items.forEach { x -> x.active = x === it }
        paint(scroll = false)
        onPick(it)
    }

    // ---------------- Lista de pistas ----------------

    private fun build() {
        val groups = player.currentTracks.groups
        val audio = ArrayList<Item>()
        val subs = ArrayList<Item>()
        var na = 0
        var ns = 0
        for (g in groups) {
            for (i in 0 until g.length) {
                val f = g.getTrackFormat(i)
                when (g.type) {
                    C.TRACK_TYPE_AUDIO -> {
                        na++
                        audio += Item(C.TRACK_TYPE_AUDIO, g, i, title(f, "Pista $na"), audioDetail(f),
                            g.isTrackSelected(i), g.isTrackSupported(i))
                    }
                    C.TRACK_TYPE_TEXT -> {
                        ns++
                        subs += Item(C.TRACK_TYPE_TEXT, g, i, title(f, "Subtítulos $ns"), subDetail(f),
                            g.isTrackSelected(i), g.isTrackSupported(i))
                    }
                }
            }
        }
        val off = Item(C.TRACK_TYPE_TEXT, null, 0, "Desactivados",
            if (subs.isEmpty()) "Esta película no tiene subtítulos" else "Sin subtítulos",
            subs.none { it.active }, true)
        cols[0].items = audio
        cols[1].items = listOf(off) + subs
        if (audio.isEmpty()) cols[0].items = listOf(Item(C.TRACK_TYPE_AUDIO, null, 0, "Sin sonido",
            "Esta película no tiene pistas de sonido", true, false))
        cols.forEach { c -> c.list.removeAllViews(); c.items.forEach { c.list.addView(card(it)) } }
    }

    private fun card(it: Item): View {
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }
        }
        card.addView(TextView(ctx).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        card.addView(TextView(ctx).apply {
            text = it.detail
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        })
        return card
    }

    private fun paint(scroll: Boolean) {
        cols.forEachIndexed { ci, c ->
            c.header.setTextColor(Color.parseColor(if (ci == col) "#E8C27A" else "#B3A493"))
            c.items.forEachIndexed { i, it ->
                val card = c.list.getChildAt(i) as LinearLayout
                val cursor = ci == col && i == c.row
                card.background = GradientDrawable().apply {
                    cornerRadius = dp(8).toFloat()
                    setColor(Color.parseColor(if (cursor) "#E8C27A" else "#2B211A"))
                }
                val ink = Color.parseColor(when {
                    cursor -> "#15110E"
                    !it.playable -> "#7A6C5E"
                    else -> "#F3E7D3"
                })
                val soft = Color.parseColor(if (cursor) "#4A3826" else if (!it.playable) "#6A5D50" else "#B3A493")
                (card.getChildAt(0) as TextView).apply {
                    text = (if (it.active) "✓  " else "") + it.title
                    setTextColor(ink)
                }
                (card.getChildAt(1) as TextView).setTextColor(soft)
            }
            if (scroll) c.list.getChildAt(c.row)?.let { v ->
                c.scroll.post { c.scroll.smoothScrollTo(0, maxOf(0, v.top - dp(80))) }
            }
        }
    }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    companion object {
        /** Aplica una pista al reproductor (también la usa el recuerdo al empezar). */
        fun select(player: ExoPlayer, it: Item) {
            val b = player.trackSelectionParameters.buildUpon()
            val g = it.group
            if (g == null) {
                if (it.type == C.TRACK_TYPE_TEXT) b.clearOverridesOfType(C.TRACK_TYPE_TEXT).setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            } else {
                b.setTrackTypeDisabled(it.type, false).setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, it.index))
            }
            player.trackSelectionParameters = b.build()
        }

        // ---------------- Nombres ----------------

        /** «Español», «Inglés (Estados Unidos)»… o null si el archivo no indica el idioma. */
        fun language(f: Format): String? {
            val l = f.language?.takeIf { it.isNotBlank() && it != "und" && it != "mul" && it != "zxx" } ?: return null
            val loc = Locale.forLanguageTag(l)
            val name = loc.getDisplayName(Locale("es")).ifBlank { l }
            return name.replaceFirstChar { it.uppercase() }
        }

        /** Nombre de la pista sin las webs que algunos meten: «Castellano [www.web.com]» → «Castellano». */
        fun label(f: Format): String? = f.label
            ?.replace(Regex("""\s*[\[(][^\])]*(www\.|\.com|\.net|\.org)[^\])]*[\])]""", RegexOption.IGNORE_CASE), "")
            ?.trim()?.takeIf { it.isNotBlank() }

        /** Título: el nombre de la pista si lo tiene (Castellano, Latino, Comentarios…) y si no, el idioma. */
        private fun title(f: Format, fallback: String): String = label(f) ?: language(f) ?: fallback

        private fun langIfTitled(f: Format): String? {
            val lang = language(f) ?: return null
            val lab = label(f) ?: return null // sin nombre, el idioma ya es el título
            return if (lab.contains(lang, ignoreCase = true)) null else lang
        }

        fun codecName(mime: String?): String = when (mime) {
            MimeTypes.AUDIO_TRUEHD -> "Dolby TrueHD"
            MimeTypes.AUDIO_E_AC3_JOC -> "Dolby Digital Plus Atmos"
            MimeTypes.AUDIO_E_AC3 -> "Dolby Digital Plus"
            MimeTypes.AUDIO_AC3 -> "Dolby Digital"
            MimeTypes.AUDIO_AC4 -> "Dolby AC-4"
            MimeTypes.AUDIO_DTS_HD -> "DTS-HD"
            MimeTypes.AUDIO_DTS_X -> "DTS:X"
            MimeTypes.AUDIO_DTS -> "DTS"
            MimeTypes.AUDIO_DTS_EXPRESS -> "DTS Express"
            MimeTypes.AUDIO_FLAC -> "FLAC"
            MimeTypes.AUDIO_AAC -> "AAC"
            MimeTypes.AUDIO_MPEG -> "MP3"
            MimeTypes.AUDIO_OPUS -> "Opus"
            MimeTypes.AUDIO_RAW -> "PCM"
            else -> mime?.substringAfter('/')?.uppercase() ?: "?"
        }

        fun channels(n: Int): String? = when (n) {
            8 -> "7.1"; 7 -> "6.1"; 6 -> "5.1"; 2 -> "2.0"; 1 -> "1.0"
            else -> if (n > 0) "$n canales" else null
        }

        private fun audioDetail(f: Format): String {
            val out = when (f.sampleMimeType) {
                MimeTypes.AUDIO_TRUEHD, MimeTypes.AUDIO_E_AC3, MimeTypes.AUDIO_E_AC3_JOC,
                MimeTypes.AUDIO_AC3, MimeTypes.AUDIO_AC4 -> "sale tal cual por HDMI"
                else -> "la SHIELD lo pasa a PCM"
            }
            val codec = listOfNotNull(codecName(f.sampleMimeType), channels(f.channelCount)).joinToString(" ")
            return listOfNotNull(langIfTitled(f), codec, out).joinToString("  ·  ")
        }

        private fun subDetail(f: Format): String {
            // Media3 convierte los subtítulos al leer el archivo; el formato original queda en «codecs».
            val mime = if (f.sampleMimeType == MimeTypes.APPLICATION_MEDIA3_CUES) f.codecs else f.sampleMimeType
            val kind = when (mime) {
                MimeTypes.APPLICATION_PGS -> "imagen (PGS)"
                MimeTypes.APPLICATION_VOBSUB -> "imagen (VobSub)"
                MimeTypes.APPLICATION_DVBSUBS -> "imagen (DVB)"
                MimeTypes.APPLICATION_SUBRIP -> "texto (SRT)"
                MimeTypes.TEXT_SSA -> "texto (ASS)"
                MimeTypes.TEXT_VTT -> "texto (WebVTT)"
                else -> mime?.substringAfter('/')
            }
            val forced = if ((f.selectionFlags and C.SELECTION_FLAG_FORCED) != 0) "forzados" else null
            return listOfNotNull(langIfTitled(f), forced, kind).joinToString("  ·  ").replaceFirstChar { it.uppercase() }
        }
    }
}

/**
 * Las pistas que elegiste en cada película, para usarlas otra vez al continuar.
 * Se guarda la posición de la pista entre las de su tipo (3.ª de sonido…) junto con su formato
 * e idioma, para no aplicar una pista distinta si el archivo ha cambiado.
 * Solo se guarda lo que tocas: si cambias el sonido y no los subtítulos, estos siguen lo de Ajustes.
 */
@OptIn(UnstableApi::class)
object Recuerdo {
    private const val FILE = "pistas"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun code(type: Int) = if (type == C.TRACK_TYPE_AUDIO) "a" else "t"

    private fun sig(f: Format) = "${f.sampleMimeType}/${f.language}"

    /** Pistas de un tipo en el orden del archivo. */
    private fun flat(tracks: Tracks, type: Int): List<Pair<Tracks.Group, Int>> =
        tracks.groups.filter { it.type == type }.flatMap { g -> (0 until g.length).map { g to it } }

    private fun read(ctx: Context, path: String): MutableMap<String, String> {
        val out = LinkedHashMap<String, String>()
        prefs(ctx).getString(path, null)?.split(';')?.forEach { part ->
            val i = part.indexOf('=')
            if (i > 0) out[part.substring(0, i)] = part.substring(i + 1)
        }
        return out
    }

    fun save(ctx: Context, path: String, tracks: Tracks, item: PanelPistas.Item) {
        val map = read(ctx, path)
        val g = item.group
        map[code(item.type)] = if (g == null) "off" else {
            val n = flat(tracks, item.type).indexOfFirst { (gg, i) -> gg.mediaTrackGroup == g.mediaTrackGroup && i == item.index }
            if (n < 0) return
            "$n|${sig(g.getTrackFormat(item.index))}"
        }
        prefs(ctx).edit().putString(path, map.entries.joinToString(";") { e -> "${e.key}=${e.value}" }).apply()
    }

    /** Aplica lo guardado. Devuelve una descripción para el registro, o null si no había nada. */
    fun restore(ctx: Context, path: String, player: ExoPlayer): String? {
        val map = read(ctx, path)
        if (map.isEmpty()) return null
        val tracks = player.currentTracks
        val done = ArrayList<String>()
        for ((k, v) in map) {
            val type = if (k == "a") C.TRACK_TYPE_AUDIO else C.TRACK_TYPE_TEXT
            if (v == "off") {
                if (type == C.TRACK_TYPE_TEXT) {
                    PanelPistas.select(player, PanelPistas.Item(type, null, 0, "", "", false, true))
                    done += "subtítulos desactivados"
                }
                continue
            }
            val n = v.substringBefore('|').toIntOrNull() ?: continue
            val (g, i) = flat(tracks, type).getOrNull(n) ?: continue
            val f = g.getTrackFormat(i)
            if (sig(f) != v.substringAfter('|')) continue // el archivo ha cambiado: se deja lo de Ajustes
            if (!g.isTrackSupported(i)) continue
            PanelPistas.select(player, PanelPistas.Item(type, g, i, "", "", false, true))
            done += (if (type == C.TRACK_TYPE_AUDIO) "sonido " else "subtítulos ") + "${n + 1} (${f.sampleMimeType} ${f.language ?: ""})"
        }
        return done.takeIf { it.isNotEmpty() }?.joinToString(", ")
    }
}

package com.jivan.micine

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Copia de seguridad en los discos USB: posiciones, películas vistas, pistas recordadas, ajustes
 * y, de la interfaz, la clave de TMDB, las fichas y las películas elegidas a mano.
 *
 * Se guarda sola (unos segundos después de cada cambio) en cada disco conectado, en dos sitios:
 *  - Android/data/com.jivan.micine/files/copia.json — siempre se puede escribir. Ojo: Android
 *    borra esta carpeta si se DESINSTALA la app con el disco conectado (instalar encima no la borra).
 *  - «Mi cine - copia de seguridad.json» en la raíz del disco, si Android deja escribir ahí.
 * Al recuperar se usa la más reciente que se encuentre.
 */
object CopiaSeguridad {
    private const val APP_FILE = "copia.json"
    private const val ROOT_FILE = "Mi cine - copia de seguridad.json"
    private val PREFS = listOf(Prefs.POSITIONS, Prefs.TRACKS, Prefs.SETTINGS)

    class Found(val json: JSONObject, val file: File, val drive: String)

    /** Discos USB conectados: (nombre, carpeta raíz). */
    private fun drives(ctx: Context, volumes: JSONArray): List<Pair<String, File>> =
        (0 until volumes.length()).map { volumes.getJSONObject(it) }
            .filter { it.optBoolean("removable") }
            .map { it.optString("name") to File(it.getString("path")) }

    /** Carpeta propia de la app en ese disco (Android/data/...), creándola si hace falta. */
    private fun appDir(ctx: Context, root: File): File? =
        ctx.getExternalFilesDirs(null).firstOrNull { it != null && it.absolutePath.startsWith(root.absolutePath + "/") }

    private fun candidates(ctx: Context, root: File): List<File> =
        listOfNotNull(appDir(ctx, root)?.let { File(it, APP_FILE) }, File(root, ROOT_FILE))

    // ---------------- Guardar ----------------

    private fun dump(p: SharedPreferences): JSONObject {
        val o = JSONObject()
        for ((k, v) in p.all) {
            val t = when (v) {
                is Long -> "l"; is Boolean -> "b"; is String -> "s"; is Int -> "i"; is Float -> "f"
                else -> continue
            }
            o.put(k, JSONArray().put(t).put(v))
        }
        return o
    }

    /** true si no hay nada que merezca guardarse (app recién instalada). */
    private fun isEmpty(ctx: Context, web: JSONObject): Boolean =
        ctx.getSharedPreferences(Prefs.POSITIONS, Context.MODE_PRIVATE).all.isEmpty() &&
            ctx.getSharedPreferences(Prefs.TRACKS, Context.MODE_PRIVATE).all.isEmpty() &&
            web.optString("key").isEmpty() && (web.optJSONObject("overrides")?.length() ?: 0) == 0

    /** Guarda la copia en todos los discos. Devuelve en cuántos se ha podido. */
    fun save(ctx: Context, volumes: JSONArray, webJson: String, version: String, force: Boolean = false): Int {
        val web = try { JSONObject(webJson) } catch (e: Exception) { JSONObject() }
        // Recién instalada: no se pisa la copia que pueda haber en el disco con una vacía.
        if (!force && isEmpty(ctx, web)) return 0
        val prefs = JSONObject()
        PREFS.forEach { prefs.put(it, dump(ctx.getSharedPreferences(it, Context.MODE_PRIVATE))) }
        val text = JSONObject()
            .put("app", "Mi cine").put("version", version).put("fecha", System.currentTimeMillis())
            .put("prefs", prefs).put("web", web)
            .toString()
        var ok = 0
        for ((_, root) in drives(ctx, volumes)) {
            var any = false
            for (f in candidates(ctx, root)) {
                try {
                    f.parentFile?.mkdirs()
                    val tmp = File(f.parentFile, f.name + ".tmp")
                    tmp.writeText(text)
                    if (!tmp.renameTo(f)) { f.delete(); if (!tmp.renameTo(f)) { tmp.delete(); continue } }
                    any = true
                } catch (e: Exception) { /* la raíz del disco puede no admitir escritura */ }
            }
            if (any) ok++
        }
        return ok
    }

    // ---------------- Buscar y recuperar ----------------

    /** La copia más reciente de todos los discos conectados, o null. */
    fun find(ctx: Context, volumes: JSONArray): Found? {
        var best: Found? = null
        for ((name, root) in drives(ctx, volumes)) {
            for (f in candidates(ctx, root)) {
                if (!f.isFile) continue
                val j = try { JSONObject(f.readText()) } catch (e: Exception) { continue }
                if (j.optString("app") != "Mi cine") continue
                if (best == null || j.optLong("fecha") > best.json.optLong("fecha")) best = Found(j, f, name)
            }
        }
        return best
    }

    /** Resumen para la interfaz: fecha, disco y cuántas películas vistas / empezadas trae. */
    fun info(found: Found?): JSONObject {
        if (found == null) return JSONObject().put("found", false)
        val pos = found.json.optJSONObject("prefs")?.optJSONObject(Prefs.POSITIONS) ?: JSONObject()
        var seen = 0
        var started = 0
        pos.keys().forEach { k ->
            when {
                k.startsWith(Prefs.SEEN_PREFIX) -> seen++
                k.startsWith(Prefs.DURATION_PREFIX) -> {}
                else -> started++
            }
        }
        return JSONObject().put("found", true).put("fecha", found.json.optLong("fecha"))
            .put("disco", found.drive).put("vistas", seen).put("empezadas", started)
    }

    /** Recupera la copia: sustituye los datos de la app. Devuelve la parte de la interfaz. */
    fun restore(ctx: Context, found: Found): JSONObject {
        val prefs = found.json.optJSONObject("prefs") ?: JSONObject()
        for (name in PREFS) {
            val o = prefs.optJSONObject(name) ?: continue
            val e = ctx.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear()
            o.keys().forEach { k ->
                val a = o.optJSONArray(k) ?: return@forEach
                when (a.optString(0)) {
                    "l" -> e.putLong(k, a.optLong(1))
                    "b" -> e.putBoolean(k, a.optBoolean(1))
                    "s" -> e.putString(k, a.optString(1))
                    "i" -> e.putInt(k, a.optInt(1))
                    "f" -> e.putFloat(k, a.optDouble(1).toFloat())
                }
            }
            e.commit()
        }
        return found.json.optJSONObject("web") ?: JSONObject()
    }
}

(function () {
  'use strict';

  var N = window.Native;                  // puente con Android (MainActivity.Bridge)
  var $ = function (id) { return document.getElementById(id); };

  // ================= Datos guardados =================
  function load(k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function save(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }

  var tmdbKey = load('micine.key', '');
  var meta = load('micine.meta', {});           // portada y ficha de cada archivo (por nombre + tamaño)
  var overrides = load('micine.overrides', {}); // película elegida a mano para un archivo

  var state = {
    tab: 'coleccion',
    films: [], scanning: false, scanned: false,
    volumes: [], positions: {}, settings: {},
    browse: null,            // carpeta abierta en «Archivos»
    focusKey: null,          // película enfocada en la colección
    detail: null             // película abierta en la ficha
  };

  function fileKey(f) { return f.name + '|' + f.size; }
  function info(f) { return meta[fileKey(f)] || null; }

  // ================= Utilidades =================
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  var toastTimer;
  function toast(m, ms) {
    var t = $('toast'); t.textContent = m; t.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove('show'); }, ms || 2600);
  }
  function gb(bytes) {
    if (!bytes) return '';
    if (bytes >= 1e12) return (bytes / 1e12).toFixed(1).replace('.', ',') + ' TB';
    return bytes >= 1e9 ? (bytes / 1e9).toFixed(1).replace('.', ',') + ' GB' : Math.round(bytes / 1e6) + ' MB';
  }
  function hms(ms) {
    var s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor(s / 60) % 60;
    return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(s % 60).padStart(2, '0');
  }
  function runtime(min) {
    if (!min) return '';
    var h = Math.floor(min / 60), m = min % 60;
    return h ? h + ' h' + (m ? ' ' + m + ' min' : '') : m + ' min';
  }
  var collator = new Intl.Collator('es', { sensitivity: 'base', numeric: true });
  function sortKey(t) { return String(t || '').replace(/^(el|la|los|las|un|una|the|a|an|le|les|il|der|die|das)\s+/i, ''); }
  function filmTitle(f) { var m = info(f); return m ? m.title : FileName.parse(f.name, f.folder).title; }
  function filmYear(f) { var m = info(f); return m ? m.year : FileName.parse(f.name, f.folder).year; }

  var ICON = {
    check: '<svg class="i" viewBox="0 0 24 24"><path d="M5 12.5l4.2 4.2L19 7"/></svg>',
    play: '<svg class="i" viewBox="0 0 24 24" style="fill:currentColor;stroke:none"><path d="M7 4.5v15l12.5-7.5z"/></svg>',
    folder: '<svg class="i" viewBox="0 0 24 24"><path d="M3 6.5A1.5 1.5 0 0 1 4.5 5h4l2 2.5h9A1.5 1.5 0 0 1 21 9v8.5a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 17.5z"/></svg>',
    film: '<svg class="i" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="1.5"/><path d="M7 5v14M17 5v14M3 9.5h4M3 14.5h4M17 9.5h4M17 14.5h4"/></svg>',
    up: '<svg class="i" viewBox="0 0 24 24"><path d="M12 19V5M5.5 11.5L12 5l6.5 6.5"/></svg>',
    list: '<svg class="i" viewBox="0 0 24 24"><path d="M9 6.5h11M9 12h11M9 17.5h11M4.5 6.5h.01M4.5 12h.01M4.5 17.5h.01"/></svg>',
    drive: '<svg class="i" viewBox="0 0 24 24"><rect x="3" y="7" width="18" height="10" rx="2"/><path d="M7 12h.01M11 12h6"/></svg>'
  };

  // ================= TMDB =================
  var API = 'https://api.themoviedb.org/3', IMG = 'https://image.tmdb.org/t/p/';
  function img(path, size) { return path ? IMG + size + path : ''; }

  function tmdb(path, params, key) {
    key = key || tmdbKey;
    var url = new URL(API + path);
    Object.keys(params || {}).forEach(function (p) { if (params[p] != null) url.searchParams.set(p, params[p]); });
    var headers = { accept: 'application/json' };
    if (key.length > 40) headers.Authorization = 'Bearer ' + key; else url.searchParams.set('api_key', key);
    return fetch(url.toString(), { headers: headers }).then(function (r) {
      if (r.status === 401) throw new Error('clave');
      if (!r.ok) throw new Error('http ' + r.status);
      return r.json();
    });
  }

  function search(title, year) {
    var q = { query: title, language: 'es-ES', include_adult: 'false' };
    return tmdb('/search/movie', Object.assign({ year: year || null }, q)).then(function (d) {
      if (d.results && d.results.length) return d.results;
      if (!year) return [];
      // Sin resultados con ese año: puede que el «año» fuera parte del título (p. ej. «Blade Runner 2049»).
      return tmdb('/search/movie', Object.assign({}, q, { query: title + ' ' + year })).then(function (d2) {
        if (d2.results && d2.results.length) return d2.results;
        return tmdb('/search/movie', q).then(function (d3) { return d3.results || []; });
      });
    });
  }

  function details(id) {
    return tmdb('/movie/' + id, { language: 'es-ES', append_to_response: 'credits' }).then(function (d) {
      var crew = (d.credits && d.credits.crew) || [], cast = (d.credits && d.credits.cast) || [];
      var m = {
        v: 2,
        id: d.id, title: d.title || d.original_title, original: d.original_title || '',
        year: (d.release_date || '').slice(0, 4), poster: d.poster_path || '', backdrop: d.backdrop_path || '',
        overview: d.overview || '', runtime: d.runtime || 0,
        genres: (d.genres || []).map(function (g) { return g.name; }),
        director: ((d.credits && d.credits.crew) || []).filter(function (c) { return c.job === 'Director'; }).map(function (c) { return c.name; }),
        cast: cast.slice(0, 4).map(function (c) { return c.name; }),
        // Para el reparto con fotos y «sus películas en tu colección»
        directors: crew.filter(function (c) { return c.job === 'Director'; }).map(function (c) {
          return { id: c.id, name: c.name, p: c.profile_path || '' };
        }),
        people: cast.slice(0, 15).map(function (c) {
          return { id: c.id, name: c.name, p: c.profile_path || '', role: c.character || '' };
        })
      };
      if (m.overview) return m;
      return tmdb('/movie/' + id, { language: 'en-US' }).then(function (e) { m.overview = e.overview || ''; return m; })
        .catch(function () { return m; });
    });
  }

  // Busca la ficha de las películas que aún no la tienen (de 3 en 3).
  var queue = [], running = 0, badKey = false;
  function enrich(films) {
    if (!tmdbKey || badKey) return;
    films.forEach(function (f) {
      var m = info(f);
      // Sin ficha, o ficha antigua sin el reparto con fotos (se actualiza sola).
      if ((!m || (!m.v && m.id)) && queue.indexOf(f) < 0) queue.push(f);
    });
    while (running < 3 && queue.length) next();
  }
  function next() {
    var f = queue.shift(); if (!f) return;
    running++;
    var k = fileKey(f);
    var old = meta[k];
    var p = overrides[k] ? Promise.resolve(overrides[k])
      : old && old.id ? Promise.resolve(old.id)
      : (function () { var n = FileName.parse(f.name, f.folder); return search(n.title, n.year).then(function (r) { return r.length ? r[0].id : null; }); })();
    p.then(function (id) { return id ? details(id) : null; })
      .then(function (m) {
        if (m) { meta[k] = m; save('micine.meta', meta); updateFilm(f); scheduleBackup(); }
      })
      .catch(function (e) { if (e.message === 'clave') { badKey = true; queue = []; toast('TMDB no acepta tu clave. Revísala en Ajustes.'); } })
      .then(function () { running--; if (queue.length) next(); });
  }

  // ================= Copia de seguridad en los discos =================
  // Se guarda sola unos segundos después de cada cambio (la parte de Android añade posiciones,
  // vistas, pistas y ajustes). Ver CopiaSeguridad.kt.
  function webBackup() { return JSON.stringify({ key: tmdbKey, meta: meta, overrides: overrides }); }
  var backupTimer;
  function scheduleBackup() {
    clearTimeout(backupTimer);
    backupTimer = setTimeout(function () { try { if (N.saveBackup) N.saveBackup(webBackup()); } catch (e) {} }, 5000);
  }
  function backupInfo() { try { return JSON.parse(N.backupInfo()); } catch (e) { return { found: false }; } }
  function fecha(ms) {
    var d = new Date(ms), two = function (n) { return String(n).padStart(2, '0'); };
    return two(d.getDate()) + '/' + two(d.getMonth() + 1) + '/' + d.getFullYear() + ' a las ' + two(d.getHours()) + ':' + two(d.getMinutes());
  }
  function restoreBackup() {
    var web = ''; try { web = N.restoreBackup(); } catch (e) {}
    if (!web) { toast('No he encontrado ninguna copia en los discos'); return false; }
    var w = {}; try { w = JSON.parse(web); } catch (e) {}
    tmdbKey = w.key || ''; meta = w.meta || {}; overrides = w.overrides || {};
    save('micine.key', tmdbKey); save('micine.meta', meta); save('micine.overrides', overrides);
    badKey = false; state.backupOffer = null;
    refreshPositions(); render(); enrich(state.films);
    toast('Copia recuperada: posiciones, vistas, pistas, ajustes y fichas', 4000);
    return true;
  }
  // App recién instalada (sin nada guardado) y hay una copia en el disco: se ofrece recuperarla.
  function checkBackupOffer() {
    if (state.backupChecked) return;
    state.backupChecked = true;
    if (tmdbKey || Object.keys(state.positions).length) return;
    var b = backupInfo();
    if (b.found && load('micine.noOffer', 0) !== b.fecha) { state.backupOffer = b; render(); }
  }

  // ================= Discos y búsqueda de películas =================
  function hasPermission() { try { return N.hasPermission(); } catch (e) { return true; } }

  function refreshVolumes() {
    try { state.volumes = JSON.parse(N.volumes()); } catch (e) { state.volumes = []; }
  }
  function refreshPositions() {
    try { state.positions = JSON.parse(N.positions()); } catch (e) { state.positions = {}; }
  }

  var scanSeq = 0;
  function scan() {
    if (!hasPermission()) { render(); return; }
    refreshVolumes();
    var roots = state.volumes.filter(function (v) { return v.removable; }).map(function (v) { return v.path; });
    // Del almacenamiento interno, solo las carpetas de vídeos y descargas.
    state.volumes.filter(function (v) { return !v.removable; }).forEach(function (v) {
      roots.push(v.path + '/Movies'); roots.push(v.path + '/Download');
    });
    state.scanning = true;
    render();
    N.scan(String(++scanSeq), JSON.stringify(roots));
  }

  window.onScan = function (id, json) {
    if (id !== String(scanSeq)) return;
    var list = [];
    try { list = JSON.parse(json); } catch (e) {}
    state.films = list;
    state.scanning = false; state.scanned = true;
    refreshPositions();
    if (list.length) checkBackupOffer();
    render();
    enrich(list);
    scheduleBackup();
  };
  window.onDrivesChanged = function () { scan(); if (state.tab === 'archivos') render(); };
  window.onPermission = function (ok) { if (ok) scan(); else render(); };
  window.onAppResume = function () {
    refreshPositions();
    scheduleBackup(); // al volver del reproductor: posición y pistas nuevas
    if (state.detail) renderDetail(); else if (state.tab === 'coleccion') render();
  };

  // ================= Navegación con el mando =================
  function layer() {
    if (!$('picker').hidden) return $('picker');
    if (!$('detail').hidden) return $('detail');
    return document.body;
  }
  function focusables() {
    return Array.prototype.filter.call(layer().querySelectorAll('[data-f]'), function (el) {
      return el.getClientRects().length && !el.closest('[hidden]');
    });
  }
  function focusEl(el) {
    if (!el) return;
    el.focus({ preventScroll: true });
    el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    if (el.dataset.key && state.tab === 'coleccion' && layer() === document.body) showMarquee(el.dataset.key);
  }
  function move(dir) {
    var cur = document.activeElement;
    var all = focusables();
    if (!cur || all.indexOf(cur) < 0) { focusEl(all[0]); return; }
    var r = cur.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    var best = null, bestScore = Infinity;
    all.forEach(function (el) {
      if (el === cur) return;
      var b = el.getBoundingClientRect(), x = b.left + b.width / 2, y = b.top + b.height / 2;
      var dx = x - cx, dy = y - cy, score;
      if (dir === 'right') { if (b.left < r.right - 6 || dx <= 0) return; score = dx + Math.abs(dy) * 2.5; }
      else if (dir === 'left') { if (b.right > r.left + 6 || dx >= 0) return; score = -dx + Math.abs(dy) * 2.5; }
      else if (dir === 'down') { if (b.top < r.bottom - 6 || dy <= 0) return; score = dy + Math.abs(dx) * 0.9; }
      else { if (b.bottom > r.top + 6 || dy >= 0) return; score = -dy + Math.abs(dx) * 0.9; }
      if (score < bestScore) { bestScore = score; best = el; }
    });
    if (best) focusEl(best);
  }

  document.addEventListener('keydown', function (e) {
    var k = e.key, a = document.activeElement;
    var inInput = a && a.tagName === 'INPUT';
    if ((k === 'ArrowUp' || k === 'ArrowDown') && a && a.classList.contains('log')) {
      // El registro se desplaza con arriba/abajo; desde el principio, arriba vuelve a los botones.
      e.preventDefault();
      if (k === 'ArrowUp' && a.scrollTop <= 0) { move('up'); return; }
      a.scrollTop += k === 'ArrowDown' ? 140 : -140; return;
    }
    if (k === 'ArrowUp' || k === 'ArrowDown') { e.preventDefault(); move(k === 'ArrowUp' ? 'up' : 'down'); return; }
    if (k === 'ArrowLeft' || k === 'ArrowRight') {
      if (inInput) return; // dentro de un campo de texto las flechas mueven el cursor
      e.preventDefault();
      if (a && a.dataset.opts) { cycle(a, k === 'ArrowRight' ? 1 : -1); return; }
      move(k === 'ArrowLeft' ? 'left' : 'right'); return;
    }
    if (k === 'Enter') {
      if (inInput) { e.preventDefault(); var t = a.dataset.enter && $(a.dataset.enter); if (t) t.click(); return; }
      if (a && a.dataset.f !== undefined) { e.preventDefault(); a.click(); }
      return;
    }
    if (k === 'Escape' || k === 'Backspace' && !inInput || k === 'GoBack' || k === 'BrowserBack') {
      e.preventDefault(); window.appBack();
    }
  });

  // Botón «atrás» del mando (lo llama Android). Devuelve false para salir de la app.
  window.appBack = function () {
    if (!$('picker').hidden) { closePicker(); return true; }
    if (!$('detail').hidden) { closeDetail(); return true; }
    if (state.tab === 'archivos' && state.browse && state.browse.parent && !isRoot(state.browse.path)) {
      openFolder(state.browse.parent); return true;
    }
    if (state.tab !== 'coleccion') { setTab('coleccion'); return true; }
    return false;
  };

  // ================= Pestañas =================
  $('tabs').addEventListener('click', function (e) {
    var b = e.target.closest('[data-tab]'); if (b) setTab(b.dataset.tab, true);
  });
  function setTab(t, keepFocus) {
    state.tab = t;
    render();
    var first = keepFocus ? document.querySelector('.tab[data-tab="' + t + '"]') : null;
    focusEl(first || defaultFocus());
  }
  function defaultFocus() {
    return $('view').querySelector('[data-f]') || document.querySelector('.tab.current');
  }

  // ================= Render principal =================
  function render() {
    document.querySelectorAll('.tab').forEach(function (b) { b.classList.toggle('current', b.dataset.tab === state.tab); });
    var v = $('view');
    v.className = 'view view-' + state.tab;
    if (state.tab !== 'coleccion') setScreen('');
    if (state.tab === 'coleccion') renderCollection(v);
    else if (state.tab === 'archivos') renderFiles(v);
    else renderSettings(v);
  }

  // ---------- Colección ----------
  function sortedFilms() {
    return state.films.slice().sort(function (a, b) { return collator.compare(sortKey(filmTitle(a)), sortKey(filmTitle(b))); });
  }
  function pos(f) { return state.positions[f.path] || {}; }

  function posterCard(f) {
    var m = info(f), p = pos(f), k = fileKey(f);
    var pct = p.pos && p.dur ? Math.min(100, Math.round(p.pos / p.dur * 100)) : 0;
    return '<button class="poster" data-f data-key="' + esc(k) + '" aria-label="' + esc(filmTitle(f)) + '">' +
      '<span class="img">' + (m && m.poster ? '<img src="' + img(m.poster, 'w342') + '" alt="">'
        : '<span class="blank">' + esc(filmTitle(f)) + (filmYear(f) ? '<small>' + esc(filmYear(f)) + '</small>' : '') + '</span>') +
      (pct && !p.seen ? '<span class="bar"><i style="width:' + pct + '%"></i></span>' : '') +
      (p.seen ? '<span class="seen">' + ICON.check + '</span>' : '') +
      '</span></button>';
  }

  function wideCard(f) {
    var m = info(f), p = pos(f), k = fileKey(f);
    var pct = p.pos && p.dur ? Math.min(100, Math.round(p.pos / p.dur * 100)) : 0;
    return '<button class="wide" data-f data-key="' + esc(k) + '">' +
      '<span class="img">' + (m && m.backdrop ? '<img src="' + img(m.backdrop, 'w500') + '" alt="">'
        : '<span class="blank"></span>') +
      '<span class="bar"><i style="width:' + pct + '%"></i></span></span>' +
      '<p class="t">' + esc(filmTitle(f)) + '</p></button>';
  }

  function renderCollection(v) {
    var empty = function (h, p, btn) {
      v.innerHTML = '<div class="empty"><h2>' + h + '</h2><p>' + p + '</p>' + (btn || '') + '</div>';
    };
    if (!hasPermission()) {
      return empty('Mi cine necesita permiso para leer tus discos',
        'Así puede encontrar las películas de tu disco duro y de tu pendrive.',
        '<button class="btn main" data-f id="btnPerm">Dar permiso</button>');
    }
    if (state.scanning && !state.films.length) return empty('Buscando películas…', 'Estoy mirando en tus discos. Con muchas carpetas puede tardar unos segundos.');
    var removable = state.volumes.filter(function (x) { return x.removable; });
    if (state.scanned && !state.films.length) {
      return removable.length
        ? empty('No he encontrado películas', 'He buscado en ' + removable.map(function (x) { return esc(x.name); }).join(', ') +
            ' y no hay archivos de vídeo (MKV, MP4…). Puedes mirar las carpetas en «Archivos».',
            '<button class="btn main" data-f id="btnGoFiles">Ver archivos</button>')
        : empty('Conecta tu disco duro o tu pendrive', 'En cuanto lo conectes a la SHIELD, buscaré tus películas.');
    }

    var films = sortedFilms();
    var cont = films.filter(function (f) { var p = pos(f); return p.pos > 60000 && !p.seen; });
    var html = '<div class="marquee" id="marquee"></div><div class="rows" id="rows">';
    var bo = state.backupOffer;
    if (bo) {
      html += '<div class="hint-bar">He encontrado una copia de seguridad de Mi cine en «' + esc(bo.disco) + '», del ' + fecha(bo.fecha) +
        ' (' + bo.vistas + ' vistas, ' + bo.empezadas + ' empezadas). ¿La recupero?' +
        '<button class="btn main" data-f id="offerYes">Recuperar</button><button class="btn" data-f id="offerNo">No</button></div>';
    } else if (!tmdbKey) {
      html += '<div class="hint-bar">Añade tu clave de TMDB para ver las portadas y las sinopsis.' +
        '<button class="btn" data-f id="btnGoSettings">Ir a Ajustes</button></div>';
    }
    if (cont.length) {
      html += '<h2 class="row-title">Seguir viendo</h2><div class="strip">' + cont.map(wideCard).join('') + '</div>';
    }
    html += '<h2 class="row-title">Tu colección<span>' + films.length + (films.length === 1 ? ' película' : ' películas') + '</span></h2>';
    html += '<div class="grid">' + films.map(posterCard).join('') + '</div></div>';
    v.innerHTML = html;
    var keep = state.focusKey && v.querySelector('[data-key="' + cssEsc(state.focusKey) + '"]');
    showMarquee(keep ? state.focusKey : (films[0] && fileKey(films[0])));
    if (layer() === document.body && (!document.activeElement || document.activeElement === document.body || !document.body.contains(document.activeElement))) {
      focusEl(keep || v.querySelector('[data-f]'));
    }
  }

  function cssEsc(s) { return String(s).replace(/["\\]/g, '\\$&'); }
  function filmByKey(k) { for (var i = 0; i < state.films.length; i++) if (fileKey(state.films[i]) === k) return state.films[i]; return null; }

  function techBadges(f) {
    var t = FileName.techInfo(f.name + ' ' + (f.folder || ''));
    var out = t.video.slice();
    if (t.audio) out.push(t.audio);
    return out;
  }

  function showMarquee(k) {
    var mq = $('marquee'); if (!mq) return;
    var f = filmByKey(k); if (!f) { mq.innerHTML = ''; setScreen(''); return; }
    state.focusKey = k;
    var m = info(f);
    var facts = [filmYear(f), m && runtime(m.runtime), m && m.genres.slice(0, 2).join(', ')].filter(Boolean);
    var tech = techBadges(f);
    mq.innerHTML = '<h1>' + esc(filmTitle(f)) + '</h1>' +
      '<p class="facts">' + esc(facts.join('  ·  ')) + (tech.length ? (facts.length ? '  ·  ' : '') + '<b>' + esc(tech.join('  ·  ')) + '</b>' : '') + '</p>' +
      (m && m.overview ? '<p class="syn">' + esc(m.overview) + '</p>' : '');
    setScreen(m && m.backdrop ? img(m.backdrop, 'w1280') : '');
  }

  var screenTimer;
  function setScreen(url) {
    var el = $('screenImg');
    clearTimeout(screenTimer);
    if (!url) { el.classList.remove('on'); return; }
    if (el.dataset.url === url) { el.classList.add('on'); return; }
    el.classList.remove('on');
    screenTimer = setTimeout(function () {
      el.style.backgroundImage = 'url("' + url + '")'; el.dataset.url = url;
      var probe = new Image(); probe.onload = function () { if (el.dataset.url === url) el.classList.add('on'); }; probe.src = url;
    }, 180);
  }

  // Cuando llega la ficha de una película, se actualiza su cartel sin perder el foco.
  function updateFilm(f) {
    var k = fileKey(f);
    if (state.tab === 'coleccion' && $('view').querySelector('.grid')) {
      var el = $('view').querySelector('.poster[data-key="' + cssEsc(k) + '"]');
      if (el) {
        var focused = document.activeElement === el;
        var tmp = document.createElement('div'); tmp.innerHTML = posterCard(f);
        var neu = tmp.firstChild; el.replaceWith(neu);
        if (focused) neu.focus({ preventScroll: true });
      }
      var w = $('view').querySelector('.wide[data-key="' + cssEsc(k) + '"]');
      if (w) {
        var wf = document.activeElement === w;
        var t2 = document.createElement('div'); t2.innerHTML = wideCard(f);
        var n2 = t2.firstChild; w.replaceWith(n2);
        if (wf) n2.focus({ preventScroll: true });
      }
      if (state.focusKey === k) showMarquee(k);
    }
    if (state.detail && fileKey(state.detail) === k) renderDetail();
  }

  $('view').addEventListener('click', function (e) {
    var c = e.target.closest('.poster, .wide');
    if (c) { var f = filmByKey(c.dataset.key); if (f) openDetail(f); return; }
    var b = e.target.closest('button'); if (!b) return;
    if (b.id === 'btnPerm') N.requestPermission();
    else if (b.id === 'btnGoFiles') setTab('archivos');
    else if (b.id === 'btnGoSettings') setTab('ajustes');
    else if (b.id === 'offerYes') restoreBackup();
    else if (b.id === 'offerNo') { save('micine.noOffer', state.backupOffer.fecha); state.backupOffer = null; render(); }
  });
  $('view').addEventListener('focusin', function (e) {
    var c = e.target.closest('.poster, .wide');
    if (c) showMarquee(c.dataset.key);
  });

  // ---------- Ficha ----------
  var detailReturn = null;
  function openDetail(f) {
    detailReturn = document.activeElement;
    state.detail = f;
    if (!info(f)) enrich([f]);
    $('detail').hidden = false;
    renderDetail();
    focusEl($('detail').querySelector('.actions [data-f]'));
    // Capítulos: se leen después de pintar la ficha (el disco puede tardar en despertar).
    if (!(f.path in chapterCache)) setTimeout(function () {
      var list = [];
      try { if (N.chapters) list = JSON.parse(N.chapters(f.path)) || []; } catch (e) {}
      chapterCache[f.path] = list;
      if (state.detail === f && list.length) renderDetail();
    }, 60);
  }
  var chapterCache = {};
  function closeDetail() {
    $('detail').hidden = true; state.detail = null;
    if (state.tab === 'coleccion') render();
    var back = detailReturn && document.body.contains(detailReturn) ? detailReturn
      : (state.focusKey && $('view').querySelector('[data-key="' + cssEsc(state.focusKey) + '"]'));
    focusEl(back || defaultFocus());
  }

  function renderDetail() {
    var f = state.detail; if (!f) return;
    var m = info(f), p = pos(f);
    var focusedId = document.activeElement && document.activeElement.id;
    var focusedPerson = document.activeElement && document.activeElement.dataset && document.activeElement.dataset.person;
    var facts = [filmYear(f), m && runtime(m.runtime), m && m.genres.join(', ')].filter(Boolean).join('  ·  ');
    var badges = techBadges(f).map(function (b) {
      return '<span class="badge' + (b === 'Dolby Vision' ? ' dv' : '') + '">' + esc(b) + '</span>';
    }).join('') + (f.size ? '<span class="badge">' + gb(f.size) + '</span>' : '');
    var resume = p.pos > 60000 && !p.seen;
    $('detail').innerHTML =
      '<div class="bg"' + (m && m.backdrop ? ' style="background-image:url(\'' + img(m.backdrop, 'w1280') + '\')"' : '') + '></div>' +
      '<div class="body">' +
        '<div class="cover"><div class="img">' + (m && m.poster ? '<img src="' + img(m.poster, 'w500') + '" alt="">'
          : '<span class="blank">' + esc(filmTitle(f)) + '</span>') + '</div></div>' +
        '<div class="text">' +
          '<h1>' + esc(filmTitle(f)) + '</h1>' +
          (m && m.original && m.original !== m.title ? '<p class="orig">' + esc(m.original) + '</p>' : '') +
          (facts ? '<p class="facts">' + esc(facts) + '</p>' : '') +
          '<div class="badges">' + badges + '</div>' +
          (m && m.overview ? '<p class="syn">' + esc(m.overview) + '</p>'
            : '<p class="syn">' + (tmdbKey ? 'Buscando la ficha de la película…' : 'Añade tu clave de TMDB en Ajustes para ver la sinopsis y la portada.') + '</p>') +
          (m && !m.v && (m.director.length || m.cast.length) ? '<p class="crew">' +
            (m.director.length ? '<b>Dirección</b> ' + esc(m.director.join(', ')) : '') +
            (m.director.length && m.cast.length ? '   ' : '') +
            (m.cast.length ? '<b>Reparto</b> ' + esc(m.cast.join(', ')) : '') + '</p>' : '') +
          '<div class="actions">' +
            (resume
              ? '<button class="btn main" data-f id="actResume">' + ICON.play + 'Continuar desde ' + hms(p.pos) + '</button>' +
                '<button class="btn" data-f id="actStart">Desde el principio</button>'
              : '<button class="btn main" data-f id="actPlay">' + ICON.play + 'Reproducir</button>') +
            ((chapterCache[f.path] || []).length ? '<button class="btn" data-f id="actChap">' + ICON.list + 'Capítulos (' + chapterCache[f.path].length + ')</button>' : '') +
            '<button class="btn" data-f id="actSeen">' + (p.seen ? 'Marcar como no vista' : 'Marcar como vista') + '</button>' +
            (tmdbKey ? '<button class="btn" data-f id="actFix">No es esta película</button>' : '') +
          '</div>' +
          peopleStrip(m) +
          '<p class="file">' + esc(f.path) + '</p>' +
        '</div>' +
      '</div>';
    if (focusedId && $(focusedId)) $(focusedId).focus({ preventScroll: true });
    else if (focusedPerson) {
      var pe = $('detail').querySelector('.person[data-person="' + focusedPerson + '"]');
      if (pe) pe.focus({ preventScroll: true });
    }
  }

  // ---------- Reparto con fotos ----------
  function initials(n) { return String(n || '').split(/\s+/).filter(Boolean).slice(0, 2).map(function (w) { return w[0]; }).join('').toUpperCase(); }
  function personCard(x, role) {
    return '<button class="person" data-f data-person="' + x.id + '" data-name="' + esc(x.name) + '">' +
      '<span class="ph">' + (x.p ? '<img src="' + img(x.p, 'w185') + '" alt="">' : '<span>' + esc(initials(x.name)) + '</span>') + '</span>' +
      '<span class="nm">' + esc(x.name) + '</span><span class="rl">' + esc(role) + '</span></button>';
  }
  function peopleStrip(m) {
    if (!m || !m.v) return '';
    var cards = (m.directors || []).map(function (d) { return personCard(d, 'Dirección'); })
      .concat((m.people || []).map(function (c) { return personCard(c, c.role); }));
    return cards.length ? '<div class="people">' + cards.join('') + '</div>' : '';
  }

  /** Películas de tu colección en las que está esa persona (dirigiendo o actuando). */
  function filmsWith(id) {
    var out = [];
    state.films.forEach(function (f) {
      var m = info(f); if (!m || !m.v) return;
      var dir = (m.directors || []).some(function (d) { return d.id === id; });
      var role = null;
      (m.people || []).forEach(function (c) { if (c.id === id && role === null) role = c.role; });
      if (dir || role !== null) out.push({ f: f, dir: dir, role: role });
    });
    // Seguidas por año
    return out.sort(function (a, b) { return (filmYear(a.f) || '').localeCompare(filmYear(b.f) || ''); });
  }

  var personOpen = null;
  function openPerson(id, name) {
    var list = filmsWith(id);
    var photo = '';
    list.some(function (x) {
      var m = info(x.f), all = (m.directors || []).concat(m.people || []);
      return all.some(function (c) { if (c.id === id && c.p) { photo = c.p; return true; } return false; });
    });
    personOpen = { id: id, from: state.detail };
    var pending = state.films.some(function (f) { var m = info(f); return m && !m.v; });
    $('picker').hidden = false;
    $('picker').innerHTML =
      '<div class="who">' + (photo ? '<img src="' + img(photo, 'w185') + '" alt="">' : '<span class="ph"><span>' + esc(initials(name)) + '</span></span>') +
      '<div><h2>' + esc(name) + '</h2><p>' + (list.length === 1 ? 'Tienes 1 película suya en tu colección.' : 'Tienes ' + list.length + ' películas suyas en tu colección.') +
      (pending ? ' Todavía estoy actualizando algunas fichas; puede que aparezcan más dentro de un momento.' : '') + '</p></div></div>' +
      '<div class="cands">' + list.map(function (x) {
        var m = info(x.f);
        var what = x.dir && x.role !== null ? 'Dirige y actúa' : x.dir ? 'Dirección' : (x.role || 'Reparto');
        return '<button class="cand" data-f data-fkey="' + esc(fileKey(x.f)) + '"><span class="img">' +
          (m.poster ? '<img src="' + img(m.poster, 'w185') + '" alt="">' : '<span class="blank">' + esc(filmTitle(x.f)) + '</span>') +
          '</span><p class="t">' + esc(filmTitle(x.f)) + '<small>' + esc([filmYear(x.f), what].filter(Boolean).join('  ·  ')) + '</small></p></button>';
      }).join('') + '</div>';
    var cur = state.detail && $('picker').querySelector('[data-fkey="' + cssEsc(fileKey(state.detail)) + '"]');
    focusEl(cur || $('picker').querySelector('[data-f]'));
  }
  function closePerson() {
    var id = personOpen && personOpen.id;
    personOpen = null; $('picker').hidden = true;
    focusEl((id && $('detail').querySelector('.person[data-person="' + id + '"]')) || $('detail').querySelector('.actions [data-f]'));
  }

  $('detail').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b || !state.detail) return;
    var f = state.detail, p = pos(f), title = filmTitle(f);
    if (b.id === 'actPlay' || b.id === 'actStart') N.play(f.path, title, 0);
    else if (b.id === 'actResume') N.play(f.path, title, p.pos || 0);
    else if (b.id === 'actSeen') {
      N.setSeen(f.path, !p.seen); refreshPositions(); renderDetail(); scheduleBackup();
      toast(p.seen ? 'Marcada como no vista' : 'Marcada como vista');
    } else if (b.id === 'actFix') openPicker(f);
    else if (b.dataset.person) openPerson(+b.dataset.person, b.dataset.name);
    else if (b.id === 'actChap') openChapters(f);
  });

  // ---------- Registro de errores ----------
  var logOpen = false;
  function openLog() {
    var text = ''; try { text = N.readLog ? N.readLog() : ''; } catch (e) {}
    // Lo más reciente arriba: se separa por entradas (cada una empieza con la fecha).
    var entries = text.split(/\n(?=\d\d\/\d\d \d\d:\d\d:\d\d  )/).filter(Boolean).reverse();
    logOpen = true;
    $('picker').hidden = false;
    $('picker').innerHTML = '<h2>Registro de errores</h2>' +
      '<p>Lo más reciente, arriba. Si algo ha fallado, haz una foto de esta pantalla (baja con ↓ para ver más).</p>' +
      '<div class="actions"><button class="btn" data-f id="logClear">Borrar registro</button></div>' +
      '<pre class="log" data-f tabindex="0">' + (entries.length ? esc(entries.join('\n')) : 'No hay nada apuntado todavía.') + '</pre>';
    focusEl($('picker').querySelector('.log'));
  }
  function closeLog() { logOpen = false; $('picker').hidden = true; focusEl($('showLog') || defaultFocus()); }

  // ---------- Capítulos ----------
  var chapterFilm = null;
  function openChapters(f) {
    var list = chapterCache[f.path] || []; if (!list.length) return;
    chapterFilm = f;
    var p = pos(f), cur = 0;
    list.forEach(function (c, i) { if (p.pos && c.t <= p.pos + 500) cur = i; });
    $('picker').hidden = false;
    $('picker').innerHTML = '<h2>Capítulos</h2>' +
      '<p>' + esc(filmTitle(f)) + '  ·  ' + list.length + ' capítulos. Elige uno para empezar a verla desde ahí.</p>' +
      '<div class="chaps">' + list.map(function (c, i) {
        return '<button class="chap' + (p.pos && i === cur ? ' now' : '') + '" data-f data-t="' + c.t + '">' +
          '<span class="n">' + (i + 1) + '</span><span class="ct">' + esc(c.title) + '</span>' +
          '<span class="tm">' + hms(c.t) + '</span></button>';
      }).join('') + '</div>';
    focusEl($('picker').querySelectorAll('.chap')[p.pos ? cur : 0]);
  }
  function closeChapters() { $('picker').hidden = true; chapterFilm = null; focusEl($('actChap') || $('detail').querySelector('[data-f]')); }

  // ---------- Elegir otra película ----------
  var pickerFilm = null;
  function openPicker(f) {
    pickerFilm = f;
    var n = FileName.parse(f.name, f.folder);
    $('picker').hidden = false;
    $('picker').innerHTML = '<h2>¿Qué película es?</h2>' +
      '<p>Elige la correcta, o cambia el título y busca otra vez.</p>' +
      '<div class="keyrow"><input id="pickQ" data-f data-enter="pickGo" value="' + esc(n.title + (n.year ? ' ' + n.year : '')) + '" aria-label="Título">' +
      '<button class="btn main" data-f id="pickGo">Buscar</button></div><div class="cands" id="cands"></div>';
    runPick(n.title, n.year);
    focusEl($('pickGo'));
  }
  function runPick(title, year) {
    $('cands').innerHTML = '<p class="span">Buscando…</p>';
    search(title, year).then(function (r) {
      if (!r.length) { $('cands').innerHTML = '<p class="span">No hay resultados. Prueba con el título original o en inglés.</p>'; return; }
      $('cands').innerHTML = r.slice(0, 18).map(function (c) {
        return '<button class="cand" data-f data-id="' + c.id + '"><span class="img">' +
          (c.poster_path ? '<img src="' + img(c.poster_path, 'w185') + '" alt="">' : '<span class="blank">' + esc(c.title) + '</span>') +
          '</span><p class="t">' + esc(c.title) + '<small>' + esc((c.release_date || '').slice(0, 4)) + '</small></p></button>';
      }).join('');
    }).catch(function () { $('cands').innerHTML = '<p class="span">No hay conexión con TMDB.</p>'; });
  }
  function closePicker() {
    if (logOpen) return closeLog();
    if (personOpen) return closePerson();
    if (chapterFilm) return closeChapters();
    $('picker').hidden = true; pickerFilm = null; focusEl($('actFix') || $('detail').querySelector('[data-f]')); }
  $('picker').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    if (personOpen && b.dataset.fkey) {
      var pf = filmByKey(b.dataset.fkey);
      personOpen = null; $('picker').hidden = true;
      if (pf) { state.detail = pf; if (!(pf.path in chapterCache)) chapterCache[pf.path] = (function () { try { return JSON.parse(N.chapters(pf.path)) || []; } catch (e) { return []; } })(); renderDetail(); focusEl($('detail').querySelector('.actions [data-f]')); }
      return;
    }
    if (b.id === 'logClear') { try { N.clearLog(); } catch (err) {} toast('Registro borrado'); openLog(); return; }
    if (chapterFilm && b.dataset.t != null) {
      var cf = chapterFilm; closeChapters();
      N.play(cf.path, filmTitle(cf), +b.dataset.t);
      return;
    }
    if (b.id === 'pickGo') {
      var q = $('pickQ').value.trim(); if (!q) return;
      var n = FileName.parse(q + '.mkv'); runPick(n.title, n.year);
      return;
    }
    if (b.dataset.id && pickerFilm) {
      var f = pickerFilm, k = fileKey(f), id = +b.dataset.id;
      overrides[k] = id; save('micine.overrides', overrides);
      toast('Cargando la ficha…');
      details(id).then(function (m) {
        meta[k] = m; save('micine.meta', meta); scheduleBackup();
        closePicker(); updateFilm(f); renderDetail(); focusEl($('detail').querySelector('.actions [data-f]'));
        toast('Ficha cambiada a «' + m.title + '»');
      }).catch(function () { toast('No se ha podido cargar esa película'); });
    }
  });

  // ---------- Archivos ----------
  function isRoot(path) { return state.volumes.some(function (v) { return v.path === path; }); }
  function openFolder(path) {
    var r; try { r = JSON.parse(N.list(path)); } catch (e) { r = { path: path, error: 'error' }; }
    state.browse = r;
    renderFiles($('view'));
    focusEl($('view').querySelector('.folder [data-f]') || defaultFocus());
  }

  function renderFiles(v) {
    if (!hasPermission()) {
      v.innerHTML = '<div class="empty"><h2>Mi cine necesita permiso para leer tus discos</h2><p>Así puede mostrar tus carpetas.</p>' +
        '<button class="btn main" data-f id="btnPerm">Dar permiso</button></div>';
      return;
    }
    refreshVolumes();
    var cur = state.browse;
    if (cur && !state.volumes.some(function (x) { return cur.path.indexOf(x.path) === 0; })) cur = state.browse = null; // disco desconectado
    var drives = state.volumes.map(function (x) {
      var on = cur && cur.path.indexOf(x.path) === 0;
      return '<button class="drive' + (on ? ' current' : '') + '" data-f data-path="' + esc(x.path) + '">' +
        '<b>' + ICON.drive + ' ' + esc(x.name) + '</b><small>' + (x.total ? gb(x.free) + ' libres de ' + gb(x.total) : '') + '</small></button>';
    }).join('');
    var folder;
    if (!cur) {
      folder = '<h3>Elige un disco</h3><p class="crumbs" style="direction:ltr">Conecta un disco duro o un pendrive y aparecerá a la izquierda.</p>';
    } else if (cur.error || cur.readable === false) {
      folder = '<h3>No puedo abrir esta carpeta</h3>';
    } else {
      var vol = state.volumes.filter(function (x) { return cur.path.indexOf(x.path) === 0; })[0];
      var rel = vol ? cur.path.slice(vol.path.length) : cur.path;
      var rows = [];
      if (vol && cur.path !== vol.path) rows.push('<button class="entry" data-f data-path="' + esc(cur.parent) + '"><span class="ico">' + ICON.up + '</span><span class="name">Volver a la carpeta anterior</span></button>');
      cur.dirs.forEach(function (d) {
        rows.push('<button class="entry" data-f data-path="' + esc(d.path) + '"><span class="ico">' + ICON.folder + '</span><span class="name">' + esc(d.name) + '</span></button>');
      });
      cur.files.forEach(function (fl, i) {
        rows.push('<button class="entry" data-f data-file="' + i + '"><span class="ico">' + ICON.film + '</span><span class="name">' + esc(fl.name) + '</span><span class="meta">' + gb(fl.size) + '</span></button>');
      });
      if (!cur.dirs.length && !cur.files.length) rows.push('<p class="crumbs" style="direction:ltr">Esta carpeta no tiene vídeos.</p>');
      folder = '<p class="crumbs">\u200E' + esc((vol ? vol.name : '') + (rel || '/')) + '</p>' + rows.join('');
    }
    v.innerHTML = '<div class="files"><div class="drives"><h3>Discos</h3>' + (drives || '<p class="crumbs" style="direction:ltr">No hay discos conectados.</p>') +
      '</div><div class="folder">' + folder + '</div></div>';
  }

  $('view').addEventListener('click', function (e) {
    if (state.tab !== 'archivos') return;
    var b = e.target.closest('button'); if (!b) return;
    if (b.dataset.path) openFolder(b.dataset.path);
    else if (b.dataset.file != null && state.browse) openDetail(state.browse.files[+b.dataset.file]);
  });

  // ---------- Ajustes ----------
  var OPTS = {
    dvConvert: { label: 'Dolby Vision perfil 7', help: 'El de los remux de UHD Blu-ray. La SHIELD no lo reproduce tal cual.',
      opts: [['true', 'Convertir a perfil 8.1'], ['false', 'Mostrar como HDR10']] },
    matchFps: { label: 'Frecuencia de la pantalla', help: 'Cambia la tele a 23,976 Hz, 24, 25… para que el movimiento sea fluido.',
      opts: [['true', 'Ajustar a la película'], ['false', 'No cambiar']] },
    audioLang: { label: 'Idioma del audio', help: 'Pista que se elige al empezar. Durante la película, manteniendo pulsado OK se abren el sonido y los subtítulos; lo que elijas allí se recuerda para esa película.',
      opts: [['es', 'Español'], ['orig', 'La del archivo']] },
    subs: { label: 'Subtítulos', help: 'Los forzados son los de carteles y diálogos en otros idiomas.',
      opts: [['forced', 'Solo forzados'], ['es', 'Español'], ['off', 'Desactivados']] }
  };

  function loadSettings() { try { state.settings = JSON.parse(N.getSettings()); } catch (e) { state.settings = {}; } }

  function settingRow(key) {
    var o = OPTS[key], val = String(state.settings[key]);
    var cur = o.opts.filter(function (x) { return x[0] === val; })[0] || o.opts[0];
    return '<button class="setting" data-f data-opts="' + key + '"><span class="lab"><b>' + o.label + '</b><small>' + o.help + '</small></span>' +
      '<span class="val"><span class="arr">‹</span>' + cur[1] + '<span class="arr">›</span></span></button>';
  }

  function cycle(el, dir) {
    var key = el.dataset.opts, o = OPTS[key];
    var i = o.opts.map(function (x) { return x[0]; }).indexOf(String(state.settings[key]));
    var n = o.opts[(Math.max(i, 0) + dir + o.opts.length) % o.opts.length];
    state.settings[key] = n[0] === 'true' ? true : n[0] === 'false' ? false : n[0];
    N.setSetting(key, n[0]);
    scheduleBackup();
    var tmp = document.createElement('div'); tmp.innerHTML = settingRow(key);
    var neu = tmp.firstChild; el.replaceWith(neu); neu.focus({ preventScroll: true });
  }

  function renderSettings(v) {
    loadSettings();
    var ver = ''; try { ver = N.version(); } catch (e) {}
    v.innerHTML = '<div class="settings">' +
      '<h2>Ajustes</h2>' +
      '<h3>Imagen</h3>' + settingRow('dvConvert') + settingRow('matchFps') +
      (state.settings.dvAvailable === false ? '<p class="note">El conversor de Dolby Vision no se ha cargado: el perfil 7 se verá en HDR10.</p>' : '') +
      '<h3>Sonido y subtítulos</h3>' + settingRow('audioLang') + settingRow('subs') +
      '<h3>Portadas y fichas (TMDB)</h3>' +
      '<div class="keyrow"><input id="keyInput" data-f data-enter="keySave" placeholder="Clave de TMDB" value="' + esc(tmdbKey) + '" autocomplete="off" spellcheck="false">' +
      '<button class="btn main" data-f id="keySave">Guardar</button></div>' +
      '<p class="note">Para no teclearla con el mando: guárdala en un archivo llamado <b>tmdb_key.txt</b> en tu pendrive, conéctalo y pulsa «Leer del pendrive».</p>' +
      '<button class="btn" data-f id="keyFile">Leer del pendrive</button> ' +
      '<button class="btn" data-f id="rescan">Buscar películas de nuevo</button> ' +
      '<button class="btn" data-f id="clearMeta">Volver a buscar las portadas</button>' +
      '<h3>Copia de seguridad</h3>' + backupBlock() +
      '<h3>Si algo falla</h3>' +
      '<p class="note">Mi cine apunta lo que pasa al reproducir: formatos, cambios de pantalla y errores.</p>' +
      '<button class="btn" data-f id="showLog">Ver registro de errores</button>' +
      '<p class="note" style="margin-top:22px">Mi cine ' + esc(ver) + '. Esta app usa la API de TMDB, pero no está respaldada ni certificada por TMDB.</p>' +
      '</div>';
  }

  function backupBlock() {
    var b = backupInfo();
    return '<p class="note">Mi cine guarda sola una copia en tus discos USB cada vez que algo cambia: dónde te quedaste, ' +
      'qué has visto, las pistas elegidas, los ajustes, la clave de TMDB y las fichas. Si reinstalas la app o cambias de SHIELD, ' +
      'conecta el disco y recupérala. Para que no se borre, instala las versiones nuevas encima de la anterior o desconecta el disco antes de desinstalar.</p>' +
      '<p class="note">' + (b.found ? 'Última copia: «' + esc(b.disco) + '», ' + fecha(b.fecha) + ' (' + b.vistas + ' vistas, ' + b.empezadas + ' empezadas).'
        : 'Todavía no hay ninguna copia en los discos conectados.') + '</p>' +
      '<button class="btn" data-f id="bkSave">Guardar copia ahora</button> ' +
      (b.found ? '<button class="btn" data-f id="bkRestore">Recuperar copia</button>' : '');
  }

  function saveKey(k) {
    k = String(k || '').trim().replace(/^Bearer\s+/i, '');
    if (!k) { toast('Escribe primero la clave'); return; }
    toast('Comprobando la clave…');
    tmdb('/configuration', {}, k).then(function () {
      tmdbKey = k; badKey = false; save('micine.key', k); scheduleBackup();
      toast('Clave guardada. Buscando portadas…');
      enrich(state.films);
      if (state.tab === 'ajustes') { renderSettings($('view')); focusEl($('keySave')); }
    }).catch(function (e) {
      toast(e.message === 'clave' ? 'TMDB no acepta esa clave' : 'No hay conexión con TMDB');
    });
  }

  $('view').addEventListener('click', function (e) {
    if (state.tab !== 'ajustes') return;
    var b = e.target.closest('button'); if (!b) return;
    if (b.dataset.opts) cycle(b, 1);
    else if (b.id === 'keySave') saveKey($('keyInput').value);
    else if (b.id === 'keyFile') {
      var k = ''; try { k = N.readKeyFile(); } catch (err) {}
      if (k) { $('keyInput').value = k; saveKey(k); } else toast('No encuentro tmdb_key.txt en ningún disco');
    } else if (b.id === 'rescan') { toast('Buscando películas…'); scan(); setTab('coleccion'); }
    else if (b.id === 'showLog') openLog();
    else if (b.id === 'bkSave') {
      var n = 0; try { n = N.saveBackupNow(webBackup()); } catch (err) {}
      toast(n ? 'Copia guardada en ' + (n === 1 ? '1 disco' : n + ' discos') : 'No hay ningún disco USB donde guardarla');
      renderSettings($('view')); focusEl($('bkSave'));
    } else if (b.id === 'bkRestore') {
      // Se pide una segunda pulsación: sustituye lo que hay ahora en la app.
      if (!b.dataset.sure) { b.dataset.sure = '1'; b.textContent = 'Pulsa otra vez: sustituye lo que hay ahora'; return; }
      if (restoreBackup()) { setTab('coleccion'); }
    }
    else if (b.id === 'clearMeta') {
      meta = {}; save('micine.meta', meta); badKey = false; toast('Buscando las portadas de nuevo…'); enrich(state.films);
    }
  });

  // ================= Arranque =================
  render();
  scan();
  focusEl(defaultFocus());
  try {
    if (N.crashed && N.crashed()) setTimeout(function () {
      toast('La última vez Mi cine se cerró por un error. Está apuntado en Ajustes → Ver registro de errores', 9000);
    }, 1200);
  } catch (e) {}
})();

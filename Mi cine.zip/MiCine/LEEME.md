# Mi cine

Reproductor de películas para Android TV (NVIDIA SHIELD 2019) pensado para remux 4K.

- **Vídeo sin recomprimir.** HDR10, Dolby Vision 5 y 8, y el perfil 7 (el de los remux de
  UHD Blu-ray) convertido a 8.1 al vuelo, mientras se reproduce, sin tocar los archivos.
- **Sonido sin pérdida.** Lo que admite la tele (Atmos, TrueHD, Dolby Digital Plus, Dolby
  Digital) sale tal cual por HDMI. Lo que no admite (DTS, DTS-HD MA y DTS:X en la LG C5) lo
  descodifica la SHIELD con FFmpeg y lo manda como PCM multicanal, también sin pérdida.
- **Ajuste de frecuencia.** La tele cambia a 23,976 Hz, 24, 25… según la película.
- **Biblioteca con portadas** (TMDB) de todo lo que haya en los discos USB, «Seguir viendo»,
  explorador de carpetas y ajustes, todo con el mando.
- **Capítulos** de los MKV: botón «Capítulos» en la ficha, marcas en la barra de progreso,
  panel con ↓ durante la película y salto con los botones siguiente / anterior.
- **Sonido y subtítulos.** Manteniendo pulsado OK (o con los botones de subtítulos y
  ajustes de la barra) se abre un panel con todas las pistas: idioma, formato y si el sonido
  sale tal cual por HDMI o lo pasa la SHIELD a PCM. Lo que eliges se recuerda para esa película.
- **Información con ↑**: formato, sonido, salida… y además la hora, a qué hora termina la película
  y cuánto queda.
- **Reparto con fotos** en la ficha. Al elegir a alguien (actor o director) se ven las películas
  suyas que tienes en la colección.
- **Copia de seguridad** automática en los discos USB (posiciones, vistas, pistas, ajustes, clave
  de TMDB y fichas). Si la app está recién instalada y encuentra una copia, ofrece recuperarla.

## Partes

- `dvconv/` — conversor Dolby Vision en Rust, con la librería de dovi_tool (`dolby_vision`).
  Tiene pruebas con muestras reales (`cargo test`, variable `DOVI_ASSETS=test-assets`).
- `app/src/main/java/.../DvExtractors.kt` — se coloca entre el lector de MKV de Media3 y el
  reproductor y convierte cada fotograma de perfil 7.
- `app/src/main/java/.../MkvChapters.kt` — lee los capítulos de la cabecera del MKV.
- `app/src/main/java/.../PanelPistas.kt` — panel de sonido y subtítulos, y el recuerdo de las pistas de cada película.
- `app/src/main/java/.../CopiaSeguridad.kt` — copia de seguridad en los discos USB.
- `app/src/main/java/.../PlayerActivity.kt` — el reproductor (Media3 ExoPlayer 1.9.4).
- `app/src/main/assets/www/` — la interfaz (biblioteca, ficha, archivos, ajustes).
- `build.yml` — compilación en GitHub: prueba el conversor, lo compila para ARM y crea el APK.

Esta app usa la API de TMDB, pero no está respaldada ni certificada por TMDB.
